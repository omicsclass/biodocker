<?php include("head.php");?>
<link href="gsds_css/about.css" type="text/css" rel="stylesheet">
<div id="page">
	<div id="toc" class="toc">
		<div id="toctitle">Contents</div>
	<ul class="contents_list">
	<li class="toclevel"><a class="contents_a" href="#level1"><span class="tocnumber">1</span> <span class="toctext">Introduction to GSDS</span></a></li>
	<li class="toclevel"><a  class="contents_a" href="#level2"><span class="tocnumber">2</span> <span class="toctext">New features in version 2.0</span></a></li>
	<li class="toclevel"><a class="contents_a" href="#level3"><span class="tocnumber">3</span> <span class="toctext">People</span></a></li>
	<li class="toclevel"><a class="contents_a" href="#level4"><span class="tocnumber">4</span> <span class="toctext">Acknowledgement</span></a></li>
	<li class="toclevel"><a class="contents_a" href="#level5"><span class="tocnumber">5</span> <span class="toctext">How to cite</span></a></li>
	</ul>
	</div>

<div id="back2top">
	<a href="#body_center">Back to top</a>
</div>


<h2 id="level1">1. Introduction to GSDS</h2>
	<p>Gene Structure Display Server (GSDS) is designed for the visualization of gene features, such as the composition and position of exons, introns, and conserved elements .etc. The input could be sequences, GenBank Accession Number (or GI), or features in BED/GTF/GFF3 formats. After inputting gene features, a high-quality image can be generated. Shape and color for features can be customized by users and further modifying functions on figures are provided. To facilitate evolutionary analysis, a phylogenetic tree can be uploaded and added on the figure. In addition, the source code for GSDS website is available for downloading (<a href="source_code/gsds_v2.tar.gz">here</a>).</p>
<h2 id="level2">2. New features in GSDS2.0</h2>
	<p>Compared with version 1.0, GSDS 2.0 has a newly designed user-interface and several new features as following:</p>
	<ul>
		<li>Support for multiple widely-used gene feature description formats including BED, GTF/GFF3 has been added.</li>
		<li>Besides exons and introns, more types of annotation features such as conserved-elements, binding sites and other functional elements can be displayed with customizable shapes/colors. </li>
		<li>The figure can be modified in feature display after its first generation, and sent to a built-in interactive editor for further refining.</li>
		<li>To facilitate evolutionary analysis, a phylogenetic tree can be uploaded and added to the side of the gene structure.</li>
	</ul>

<h2 id="level3">3. People</h2>
	<p>Faculties</p>
		<ul class="list_people">
		<li>Gao Ge (gaog at mail.cbi.pku.edu.cn)</li>
		<li>Luo Jingchu (luojc at mail.cbi.pku.edu.cn)</li>
		</ul>
	<p>Students</p>
		<ul class="list_people">
		<li>Hu Bo (hubo.bnu at gmail.com)</li>
		<li>Jin Jinpu (jinjp at mail.cbi.pku.edu.cn)</li>
		</ul>
	<p>Previous Developers and Maintainers</p>
		<ul class="list_people">
		<li>Guo Anyuan (guoay at mail.cbi.pku.edu.cn)</li>
		<li>Zhu Qihui (zhuqh at mail.cbi.pku.edu.cn)</li>
		<li>Chen Xin (chenx at mail.cbi.pku.edu.cn)</li>
		<li>Zhang He (zhangh at mail.cbi.pku.edu.cn)</li>
		</ul>
<h2 id="level4">4. Acknowledgement</h2>
	<p>Thanks for the developers of SVG-edit, and all comments from users. </p>
<h2 id="level5">5. How to Cite</h2>
	<p>Bo Hu, Jinpu Jin, An-Yuan Guo, He Zhang, Jingchu Luo and Ge Gao. (2014). GSDS 2.0: an upgraded gene feature visualization server. <i>Bioinformatics</i>, DOI:10.1093/bioinformatics/btu817 (in press).</p>
	</div>

<?php include("foot.html");?>
