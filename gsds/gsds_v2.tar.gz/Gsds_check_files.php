<?php
error_reporting (E_ALL ^ E_NOTICE);
// get the random id
$ran=$_GET['ran'];
$intron_phase=$_GET['intron'];
$image_format=$_GET['image'];
$width=$_GET['width'];
$type=$_GET['type']; // Site, FASTA sequences, GTF/GFF3 or GI
$color=$_GET['color'];
$radio=$_GET['radio'];
$protein_coords=$_GET['protein_coords'];

$upload_dir="task/upload_file/";
$gi=$upload_dir.$ran.".gi";
$cds=$upload_dir.$ran.".cds";
$gene=$upload_dir.$ran.".gene";
$site=$upload_dir.$ran.".site";
$gene_length=$upload_dir.$ran.".gene_length";
$gff=$upload_dir.$ran.".gff";
$order=$upload_dir.$ran.".order";
$tree=$upload_dir.$ran.".tree";

// function to check whether the file is in FASTA format or not
function check_dna_fasta($fp,$seq){
	$first=0;
	$format="";	
	while ($line=fgets($fp,1024)){
		// ignore the space line
		if (preg_match("/^\s+$/",$line)){
			next;
		}
		else {
			// the first line should begin with > for the FASTA format
			if ($first==0 ){
				if (preg_match("/^>/",$line)){
					$format="fasta";
				}			
			}
			// FASTA format
			if ($format=="fasta"){
				// if FASTA and the lines not begin with >, it should contain only ACGTN for DNA sequences
				if ((!preg_match("/^>/",$line))){
					if(preg_match("/[^ACGTacgtNn*\r\n ]/",$line)){
						$format="nonfasta";
						return array($format,$first);
				}
			}
			else {
				$format="fasta";
				$first++;
			}
		}
		}
	}
	return array($format,$first);
}
// GI file, gene order file, these id can be separated by ',', ' ;', space, tab, and '\n' etc.

// check the format of BED file.
//format for each line: <gene name> <star> <end> <feature type> <cds phase(optional)>
function check_bed_file($fp){	
	$line_num=0;
	while ($line=fgets($fp,1024)){
		if (!preg_match("/^\s+$/",$line)){
			if (!preg_match("/^\S+\s+\d+\s+\d+\s+\S/",$line)and !preg_match("/^\S+\s+\d+\s+\d+\s+\S+\s+\S+/",$line)){
				return array(false,$line_num+1);
			}
		}
		$line_num++;
	}
	return array(true,$line_num);
}

// check the format of domain file.
function check_domain_file($fp){	
	$line_num=1;
	while ($line=fgets($fp,1024)){
		// each line should like this: seqname start end feature_name
		if (!preg_match("/^\S+\s+\d+\s+\d+\s+\S+/",$line)){
			return array(false,$line_num);
		}
		$line_num++;
	}
	return array(true, $line_num);
}
//check the format of gff file
function check_gff_file($fp)
{
	$num=0;
	$gff_format="";
	$gff_source="";
	while ($line=fgets($fp)){
		// ignore the spaced lines and comments
		if (preg_match("/^(#|(\s+$))/",$line)){
			$num++;
			continue;
		}elseif(preg_match("/^(\S+\s+){3}(\d+\s+){2}\S+\s+(\+|\-|\.)\s+(0|1|2|\.)\s+(.+)$/",$line,$matches)){
		if(!$gff_format){
$gff_format="gff";}
		if(preg_match("/=/",$matches[5])){
		$cur_gff_format="gff.gff3";
			if($gff_format=="gff"){
			$gff_format=$cur_gff_format;
			}elseif($gff_format != $cur_gff_format){
			$gff_format="inconsitent";
			return array($gff_format,$num+1);	
			}
		}elseif(preg_match("/\".+\";/U",$matches[5])){
		$cur_gff_format="gff.gtf";
			if($gff_format=="gff"){
			$gff_format=$cur_gff_format;
			}elseif($gff_format != $cur_gff_format){
			$gff_format="inconsitent";
			return array($gff_format,$num+1);	
			}
		}
		if(preg_match("/pacid=/",$matches[5]) and $gff_format=="gff.gff3"){
		$gff_source=".phytozome";
		}
		}else{
		return array($gff_format,$num+1);
		} 
		$num++;
	}
	return array($gff_format.$gff_source,$num);
}
// function to check the gene order file
function check_gene_order($fp){
	while ($line=fgets($fp,1024)){
		// each line should be a sequence name
		if (!preg_match("/^\s*\S+\s*$/",$line)){
			return false;
		}
	}
	return true;
}

// check whether the file is tree file
function check_tree_file($fp){	

	while ($line=fgets($fp,1024)){
		if (preg_match("/;/",$line)){
			return true;
		}
	}
	return false;
}

$file="";
if ($type=="seq"){
	// no cds or gene file uploaded
	if (!file_exists($cds) ||!file_exists($gene) ){
		report_error("No CDS or Gene sequence file uploaded!");
	}
	// check the file size 
	if (filesize("$cds")>100000 || filesize("$gene")>100000 ) {
		report_error("The input CDS or Gene sequence file is too large, the size limitation is 100K currently.");
	}
	$fpcds=fopen("$cds","r") or die("Open CDS file Error!");
	$fpgene=fopen("$gene","r") or die("Open gene file Error!");
	list($cdsformat,$cds_num)=check_dna_fasta($fpcds,"cds");
	list($geneformat,$gene_num)=check_dna_fasta($fpgene,"gene");

	if ($cdsformat=="fasta" && $geneformat=="fasta"){
		if ($cds_num>50 ||$gene_num>50){
			report_error("The input sequence number is too large, the limitation for the input sequences is 20 currently.");
		}
		$file="fasta";
	}	
	else{
		report_error("The CDS or Gene sequences should be both in FASTA format!");
	}
}
elseif ($type=="gi"){
	if (!file_exists($gi)){
		report_error("No accession number/gi uploaded!");
	}else{
		if(!fopen("$gi","r")){
			report_error("Open accession number/gi file error!");
		}
	}
	$file="gi";
}
elseif ($type=="site"){
	if (!file_exists($site)){
		report_error("No BED file uploaded!");
	}else{
		if(filesize("$site")>50000){
			report_error("The BED file input is too large.<br> Its size limitation is 50K currently.");
		}else{
			if(!fopen("$site","r")){
				report_error("Open file Error!");
			}else{
				$fpsite=fopen("$site","r");
				list($site_check,$line_num)=check_bed_file($fpsite);
				if (!$site_check){
				report_error("Line $line_num in the <a href='Gsds_help.php#level2-1-1'> BED</a> file is not in the correct format, please check it.");
				}
			}
		}
	}
	$file="site";	

} elseif ($type='gff') {
	if(!file_exists($gff))
	{
		report_error("No GFF file uploaded!");
	}else{
		if(filesize("$gff")>50000){
			report_error("The GFF file input is too large.<br> The size limitation is 50K currently.");
		}else
			if(!fopen("$gff","r")){
				report_error("Open file Error!");
			}
			$fpgff=fopen("$gff","r");
			list($gff_format,$line_num)=check_gff_file($fpgff);
			if($gff_format=="gff.gtf" or preg_match("/^gff.gff3/",$gff_format)){
				$file=$gff_format;
			}elseif(!$gff_format){
				report_error("Line $line_num is not in the correct <a href='Gsds_help.php#level2-1-2'>GFF</a> format, please check it.");
			}elseif($gff_format=="gff"){
				report_errot("The GFF file should be either <a href='Gsds_help.php#level2-1-2'>GTF</a> or <a href='Gsds_help.php#level2-1-2'>GFF3</a>. Line $line_num is not in the correct format, please check it.");
			}elseif($gff_format=="inconsistent"){
				report_error("Error! The GFF file should be either <a href='Gsds_help.php#level2-1-2'>GTF</a> or <a href='Gsds_help.php#level2-1-2'>GFF3</a>, but not a mix of them. Please check it at line $line_num.");
			}else{
				report_error("GFF format error!");
			}
	}
}
// check domain position file
$domain=$upload_dir.$ran.".domain";
if (file_exists($domain)){
	$domain_exists=1;
	if(filesize("$domain")>50000){
			report_error("The other feature file input is too large.<br> The size limitation is 50K currently.");
	}else if(!fopen("$domain","r")){
			report_error("Could not open the other feature file.");
	}
	$fpdomain=fopen("$domain","r");
	list($domain_format,$line_num)=check_domain_file($fpdomain);
#	if (!check_domain_file($fpdomain)){
	if(! $domain_format){
		report_error("Line $line_num in the other feature file is not in the correct format, please check it.");
	}
}
// check tree order file

if (file_exists($tree)){
$tree_exists=1;
	if(filesize("$tree")>50000){
			report_error("The tree file input is too large.<br> The size limitation is 50K currently.");
	}else{
		if(!fopen("$tree","r")){
			report_error("Could not open the tree file.");
		}
		$fptree=fopen("$tree","r");
		if (!check_tree_file($fptree)){
		report_error("The tree file is not in the correct format. It should be Newick tree which ended by a semicolon (;).");
		}
	}
}
// check gene order file
if (file_exists($order)){
	if(filesize("$order")>50000){
			report_error("The order file input is too large.<br> The size limitation is 50K currently.");
	}else{
		if(!fopen("$order","r")){
			report_error("Could not open the order file.");
		}
		$fporder=fopen("$order","r");
		if (!check_gene_order($fporder)){
			report_error("The gene order file is not in the correct format. Each line should contain just one sequence name in the file.");
		}
	}
}
function report_error($error_string){
	$errors[]=$error_string;
	$errors=serialize($errors);
	$errors=base64_encode($errors);
	echo "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0; url=Gsds_error_page.php?&errors=$errors\">";
	die();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<?php 
echo "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0; url=Gsds_cgi.php?ran=$ran&image=$image_format&intron=$intron_phase&width=$width&file=$file&domain_exists=$domain_exists&protein_coords=$protein_coords&tree_exists=$tree_exists\">";
?>
<link rel="icon" href="Gsds_images/small_logo.gif" type="image/x-icon" />
<link rel="SHORTCUT ICON" href="Gsds_images/small_logo.gif" type="image/x-icon" />
<link href="gsds_css/head.css" type="text/css" rel="stylesheet">
<link href="gsds_css/program_run.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="jquery/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="jquery/jquery-migrate-1.2.1.min.js"></script>
<title>Gene Structure Display Server 2.0</title>
</head>

<?php include("head_run.html");?>
<div id="run_box">
	<div id="run_text">
		<font color="#2299DD">You job is running..., Please be patient...</font>
	</div>
	<img id="run_gif" src="Gsds_images/loading.gif">
</div>
</div>
</body>
</html>
