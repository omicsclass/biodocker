<?php 
//define the shape required in the drawing

//Lines
function my_line($x1,$y1,$x2,$y2,$color,$str_w){
	global $fsvg;
	if(!$str_w){$str_w=1;}
	if(preg_match("/^#/",$tree_color)){
		fwrite($fsvg,"<line x1='$x1' y1='$y1' x2='$x2' y2='$y2' style=\"stroke:$color;stroke-width:$str_w\"/>\n");
	}else{
		fwrite($fsvg,"<line x1='$x1' y1='$y1' x2='$x2' y2='$y2' style=\"stroke:#000000;stroke-width:$str_w\"/>\n");
	}
}

//Line in the tree
function tree_line($x1,$y1,$x2,$y2,$color,$str_w){
	global $fsvg;
	if(!$str_w){$str_w=1;}
	if(preg_match("/^#/",$color)){
		fwrite($fsvg,"<line x1='$x1' y1='$y1' x2='$x2' y2='$y2' style=\"stroke:$color;stroke-width:$str_w\"/>\n");
	}else{
		gradient_filled_line($x1,$y1,$x2,$y2,"#tree_grad",$str_w);
	}
}

//Text
function my_string($x,$y,$text,$size,$color){
	global $fsvg;
	fwrite($fsvg,"<text x='$x' y='".($y+5)."' font-size='$size' style=\"fill:$color\">$text</text>\n");
}

//Line for introns.
function intron_line($x1,$x2,$y,$type){
	global $fsvg;
	if(!$type["stroke_width"]){$type["stroke_width"]=1;}
	if($type['solid']){
		fwrite($fsvg,"<line x1='$x1' y1='$y' x2='$x2' y2='$y' style=\"stroke:".$type["color"].";stroke-width:".$type["stroke_width"]."px\"/>\n");
	}else{
		$type_copy=$type;
		$type_copy["height"]=$type["stroke_width"];
		$type_copy["filled"]=1;
		rectangle($x1,$x2,$y,$type_copy);
	}
}

//Dash line for introns
function dashed_intron_line($x1,$x2,$y,$type){
	global $fsvg;
	if($type['solid']){
		fwrite($fsvg,"<line x1='$x1' y1='$y' x2='$x2' y2='$y' style=\"stroke:".$type["color"].";stroke-dasharray:5,3;stroke-width:".$type["stroke_width"]."px\"/>\n");
	}else{
		$type_copy=$type;
		$type_copy["height"]=$type["stroke_width"];
		$type_copy["filled"]=1;
		rectangle($x1,$x2,$y,$type_copy);
		fwrite($fsvg,"<line x1='$x1' y1='$y' x2='$x2' y2='$y' style=\"stroke:#ffffff;stroke-dasharray:5,3;stroke-width:".$type["stroke_width"]."px\"/>\n");
		
	}
}

//shrinked line for introns
function shrinked_intron_line($x1,$x2,$y,$type){
	global $fsvg;
	$dash_h=6;
	$dash_dis=4;
	$dash_x=2;
	if(($x2-$x1)<($dash_dis+$dash_x*2)){
		$dash_dis=($x2-$x1)/2;
	}
	if($type['solid']){
		fwrite($fsvg,"<line x1='$x1' y1='$y' x2='".(($x1+$x2)/2-$dash_dis/2)."' y2='$y' style=\"stroke:".$type["color"].";stroke-width:".$type["stroke_width"]."px\"/>\n");
		fwrite($fsvg,"<line x1='".(($x1+$x2)/2-$dash_dis/2-$dash_x)."' y1='".($y+$dash_h/2)."' x2='".(($x1+$x2)/2-$dash_dis/2+$dash_x)."' y2='".($y-$dash_h/2)."' style=\"stroke:".$type["color"]."\"/>\n");
		fwrite($fsvg,"<line x1='".(($x1+$x2)/2+$dash_dis/2-$dash_x)."' y1='".($y+$dash_h/2)."' x2='".(($x1+$x2)/2+$dash_dis/2+$dash_x)."' y2='".($y-$dash_h/2)."' style=\"stroke:".$type["color"]."\"/>\n");
		fwrite($fsvg,"<line x1='".(($x1+$x2)/2+$dash_dis/2)."' y1='$y' x2='$x2' y2='$y' style=\"stroke:".$type["color"].";stroke-width:".$type["stroke_width"]."px\"/>\n");
	}else{
		gradient_filled_line($x1,$y,(($x1+$x2)/2-$dash_dis/2),$y,'#'.$type['grad_id'].'_grad',$type["stroke_width"]);
		gradient_filled_line((($x1+$x2)/2-$dash_dis/2-$dash_x),($y+$dash_h/2),(($x1+$x2)/2-$dash_dis/2+$dash_x),($y-$dash_h/2),'#'.$type['grad_id'].'_grad',1);
		gradient_filled_line((($x1+$x2)/2+$dash_dis/2-$dash_x),($y+$dash_h/2),(($x1+$x2)/2+$dash_dis/2+$dash_x),($y-$dash_h/2),'#'.$type['grad_id'].'_grad',1);
		gradient_filled_line((($x1+$x2)/2+$dash_dis/2),$y,$x2,$y,'#'.$type['grad_id'].'_grad',$type["stroke_width"]);
	}
}

//hat for introns
function hat($x1,$x2,$y,$type){
	global $fsvg;
	$h=4;
	$s=$type["stroke_width"];
	if($type["solid"]){
		fwrite($fsvg,"<polygon points='$x1,$y $x1,".($y+$s)." ".(($x1+$x2)/2).",".($y+$h+$s)." $x2,".($y+$s)." $x2,$y ".(($x1+$x2)/2).",".($y+$h)."' style=\"fill:".$type["color"]."\"/>\n");
	}else{
		fwrite($fsvg,"<polygon points='$x1,$y $x1,".($y+$s)." ".(($x1+$x2)/2).",".($y+$h+$s)." $x2,".($y+$s)." $x2,$y ".(($x1+$x2)/2).",".($y+$h)."' style=\"fill:url(#".$type["grad_id"]."_grad)\"/>\n");
	}
}

//rectangle for features (e.g., exons, introns, other domain features etc.)
function rectangle($x1,$x2,$y,$type){
	global $fsvg;
	$h=$type["height"];
	if($type["filled"]){
		if($type["solid"]){
			fwrite($fsvg,"<rect x='$x1' y='".($y-$h/2)."' width='".($x2-$x1)."' height='$h' style=\"fill:".$type["color"].";\"/>\n");
		}else{
			fwrite($fsvg,"<rect x='$x1' y='".($y-$h/2)."' width='".($x2-$x1)."' height='$h' style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
		}
	}else{
		if($type["solid"]){
			fwrite($fsvg,"<rect x='$x1' y='".($y-$h/2)."' width='".($x2-$x1)."' height='$h' style=\"fill:#FFFFFF;stroke:".$type["color"]."\"/>\n");
		}else{
			fwrite($fsvg,"<rect x='$x1' y='".($y-$h/2)."' width='".($x2-$x1)."' height='$h' style=\"fill:url(#".$type["grad_id"]."_grad);)\"/>\n");
			fwrite($fsvg,"<rect x='".($x1+1)."' y='".($y-$h/2+1)."' width='".($x2-$x1-2)."' height='".($h-2)."' style=\"fill:#FFFFFF;\"/>\n");
		}
	}
}

//wedge for features (e.g., exons, introns, other domain features etc.)
function wedge($x1,$x2,$y,$type){
	global $fsvg;
	$h=$type["height"];
	if(($x2-$x1)>15){
		$w=15;
	}else{
		$w=($x2-$x1)/3;
	}
	if($type["filled"]){
		fwrite($fsvg,"<polygon points='$x1,".($y-$h/2)." ".($x2-$w).",".($y-$h/2)." $x2,$y ".($x2-$w).",".($y+$h/2)." $x1,".($y+$h/2)."'");
		if($type["solid"]){
			fwrite($fsvg," style=\"fill:".$type["color"].";\"/>\n");
		}else{
			fwrite($fsvg," style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
		}
	}else{
		if($type["solid"]){
			fwrite($fsvg,"<polygon points='$x1,".($y-$h/2)." ".($x2-$w).",".($y-$h/2)." $x2,$y ".($x2-$w).",".($y+$h/2)." $x1,".($y+$h/2)."' style=\"fill:#FFFFFF;stroke:".$type["color"].";\"/>\n");
		}else{
			fwrite($fsvg,"<polygon points='$x1,".($y-$h/2)." ".($x2-$w).",".($y-$h/2)." $x2,$y ".($x2-$w).",".($y+$h/2)." $x1,".($y+$h/2)."' style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
			fwrite($fsvg,"<polygon points='".($x1+1).",".($y-$h/2+1)." ".($x2-$w-1).",".($y-$h/2+1)." ".($x2-1).",$y ".($x2-$w-1).",".($y+$h/2-1)." ".($x1+1).",".($y+$h/2-1)."' style=\"fill:#FFFFFF;\"/>\n");
		}
	}
}

//double sided wedge for features (e.g., exons, introns, other domain features etc.)
function double_sided_wedge($x1,$x2,$y,$type){
	global $fsvg;
	$h=$type["height"];
	if(($x2-$x1)>20){
		$w=10;
	}else{
		$w=($x2-$x1)/4;
	}
	fwrite($fsvg,"<polygon points='$x1,$y ".($x1+$w).",".($y-$h/2)." ".($x2-$w).",".($y-$h/2)." $x2,$y ".($x2-$w).",".($y+$h/2)." ".($x1+$w).",".($y+$h/2)."'");
	if($type["filled"]){
		if($type["solid"]){
			fwrite($fsvg," style=\"fill:".$type["color"].";\"/>\n");
		}else{
			fwrite($fsvg," style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
		}
	}else{
		if($type["solid"]){
			fwrite($fsvg," style=\"fill:#FFFFFF;stroke:".$type["color"].";\"/>\n");
		}else{
			fwrite($fsvg," style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
			fwrite($fsvg,"<polygon points='".($x1+1).",$y ".($x1+$w).",".($y-$h/2+1)." ".($x2-$w).",".($y-$h/2+1)." ".($x2-1).",$y ".($x2-$w).",".($y+$h/2-1)." ".($x1+$w).",".($y+$h/2-1)."' style=\"fill:#FFFFFF;\"/>\n");
		}
	}
}

//round corner rectangle for features (e.g., exons, introns, other domain features etc.)
function round_corner_rectangle($x1,$x2,$y,$type){
	global $fsvg;
	$h=$type["height"];
	$r=$h*0.4;
	fwrite($fsvg,"<rect x='$x1' y='".($y-$h/2)."' rx='$r' ry='$r' width='".($x2-$x1)."' height='$h'");
	if($type["filled"]){
		if($type["solid"]){
			fwrite($fsvg, " style=\"fill:".$type["color"].";\"/>\n");
		}else{
			fwrite($fsvg," style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
		}
	}elseif($type["solid"]){
 		fwrite($fsvg, " style=\"fill:#FFFFFF;stroke:".$type["color"]."\"/>\n");
	}else{
		fwrite($fsvg," style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
		fwrite($fsvg,"<rect x='".($x1+1)."' y='".($y-$h/2+1)."' rx='$r' ry='$r' width='".($x2-$x1-2)."' height='".($h-2)."' style=\"fill:#FFFFFF\"/>");
	}
}

//gradient filled line
function gradient_filled_line($x1,$y1,$x2,$y2,$url,$sw){
	global $fsvg;
	if($x1==$x2){
	fwrite($fsvg, "<polygon points='".($x1-$sw/2).",$y1 ".($x1+$sw/2).",".$y1." ".($x2+$sw/2).",".$y2." ".($x2-$sw/2).",$y2' style=\"fill:url($url);\"/>\n");
	}else{
	fwrite($fsvg, "<polygon points='$x1,".($y1-$sw/2)." $x1,".($y1+$sw/2)." $x2,".($y2+$sw/2)." $x2,".($y2-$sw/2)."' style=\"fill:url($url);\"/>\n");
	}
}

//point triangle for single nucleotide feature
function point_wedge($x,$n,$s,$y,$type){
	global $fsvg;
	$h=$type["height"];
	$w=$type["arrow_width"];
	$ys=$type["y_shift"];
	$up=$type["arrow_up"];
	if(!$w){$w=4;}
	if(!$ys){$ys=0;}
	if(!$up or ($up!=1 and $up!=-1)){$up=-1;}
	$h=$h*$up;
	$y=$y+$ys;
	for($i=0;$i<$n;$i++){
		$xi=$x+$s*$i;
		fwrite($fsvg,"<polygon points='".($xi-$w/2).",".($y+$h)." $xi,".($y)." ".($xi+$w/2).",".($y+$h)."'");
		if($type["solid"]){
		fwrite($fsvg," style=\"fill:".$type["color"].";stroke:".$type["color"]."\"/>\n");
		}else{
			fwrite($fsvg," style=\"fill:url(#".$type["grad_id"]."_grad);\"/>\n");
		}
	}
}

//arrow for single nucleotide feature
function point_arrow($x,$n,$s,$y,$type){
	global $fsvg;
	$h=$type["height"];
	$w=$type["arrow_width"];
	$ys=$type["y_shift"];
	$up=$type["arrow_up"];
	if(!$w){$w=4;}
	if(!$ys){$ys=0;}
	if(!$up or ($up!=1 and $up!=-1)){$up=-1;}
	$h=$h*$up;
	$y=$y+$ys;
	$dh=2;
	for($i=0;$i<$n;$i++){
		$xi=$x+$s*$i;
		if($type["solid"]){
		fwrite($fsvg,"<line x1='$xi' y1='$y' x2='$xi' y2='".($y+$h)."' style=\"stroke:".$type["color"].";stroke-width:2px\"/>\n");
		fwrite($fsvg,"<line x1='$xi' y1='$y' x2='".($xi-$w/2)."' y2='".($y+$h/$dh)."' style=\"stroke:".$type["color"].";stroke-width:2px\"/>\n");
		fwrite($fsvg,"<line x1='$xi' y1='$y' x2='".($xi+$w/2)."' y2='".($y+$h/$dh)."' style=\"stroke:".$type["color"].";stroke-width:2px\"/>\n");
		}else{
		gradient_filled_line($xi,$y,$xi,$y+$h,'#'.$type['grad_id'].'_grad',2);
		gradient_filled_line($xi,$y,$xi-$w/2,$y+$h/$dh,'#'.$type['grad_id'].'_grad',2);
		gradient_filled_line($xi,$y,$xi+$w/2,$y+$h/$dh,'#'.$type['grad_id'].'_grad',2);
		}
	}
}

?>
