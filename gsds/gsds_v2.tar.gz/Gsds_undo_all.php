<?php
//cancel the modification and back to the original state 
$ran=$_POST["ran"];
if(file_exists("task/$ran/previous.svg")){
	$cp_svg_cmd=escapeshellcmd("cp task/$ran/previous.svg task/$ran/$ran.svg");
	exec($cp_svg_cmd);
}
?>
