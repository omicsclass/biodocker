<?php
//get the parameters for drawing and redrawing

if($_POST['redraw']){
$redraw=$_POST['redraw'];
}elseif($_GET['redraw']){
$redraw=$_GET['redraw'];
}

if ($redraw){
	$ran=$_POST['ran'];
	$intron_phase=$_POST['intron_phase'];
	$width=$_POST['width'];
	$color=$_POST['color'];
	$file=$_POST['file'];
	$intron_rescale=$_POST['intron_rescale'];
	$intron_zoom=$_POST['intron_zoom'];
	//$intron_zoom=0.01;

	$cgi_info=base64_decode($_POST['cgi_info']);
	$cgi_info=unserialize($cgi_info);
	if($cgi_info['order_by_gene_id']){
		$g_num=$cgi_info['g_num']+$cgi_info['lack_id_num'];
	}else{
		$t_num=$cgi_info['t_num']+$cgi_info['lack_id_num'];
	}

	$intron=array(
		"name"=>"intron",
		"grad_id"=>"intron",
		"color"=>urldecode($_POST['intron_color']),
		"shape"=>$_POST['intron_shape'],
		"stroke_width"=>$_POST['intron_stoke_width'],
	);
	$exon=array(
		"name"=>"exon",
		"grad_id"=>"exon",
		"color"=>urldecode($_POST['exon_color']),
		"shape"=>$_POST['exon_shape'],
		"filled"=>$_POST['exon_isfilled'],
		"height"=>$_POST['exon_height'],
	);
	$utr=array(
		"name"=>"utr",
		"grad_id"=>"utr",
		"color"=>urldecode($_POST['utr_color']),
		"shape"=>$_POST['utr_shape'],
		"filled"=>$_POST['utr_isfilled'],
		"height"=>$_POST['utr_height'],
	);
	
	$domain_num=sizeof($_POST['domain_name']);
	if($domain_num){
	for($d_n=0;$d_n<$domain_num;$d_n++){
		$domains[]=array (
			"name"=>$_POST['domain_name'][$d_n],
			"grad_id"=>"domain".($d_n+1),
			"color"=>urldecode($_POST['domain_color'][$d_n]),
			"shape"=>$_POST['domain_shape'][$d_n],
			"filled"=>$_POST["domain".($d_n+1)."_isfilled"],
			"height"=>$_POST['domain_height'][$d_n],
			"height_on_intron"=>$_POST['domain_height_on_intron'][$d_n],
			"display"=>$_POST['domain_display'][$d_n],
		);
		if(preg_match("/point_/",$domains[$d_n]["shape"])){
			$domains[$d_n]["arrow_width"]=$_POST['domain_aw'][$d_n];
			$domains[$d_n]["y_shift"]=$_POST['domain_ys'][$d_n];
			$domains[$d_n]["arrow_up"]=$_POST["domain".($d_n+1)."_up"];
		}
	}
	}else{
		$domains=array();
	}
	$tree_width=$_POST["tree_width"];
	$tree_strw=$_POST["tree_strw"];
	$tree_color=$_POST["tree_color"];
	$tree_color=urldecode($tree_color);

}else{
	$image_format=$_GET['image'];
	$ran=$_GET['ran'];
	$intron_phase=0;
	if(preg_match("/no/i",$intron_phase)){
		$intron_phase=0;
	}
	$width=$_GET['width'];
	$color=$_GET['color'];
	$file=$_GET['file'];
	$intron_rescale=0;

	$cgi_info_str=$_GET['cgi_info'];
	$cgi_info=urldecode($cgi_info_str);
	$cgi_info=my_json_decode($cgi_info);

	if($cgi_info['order_by_gene_id']){
		$g_num=$cgi_info['g_num']+$cgi_info['lack_id_num'];
	}else{
		$t_num=$cgi_info['t_num']+$cgi_info['lack_id_num'];
	}
//var_dump($cgi_info);
$has_phase=0;

	$intron=array(
		"name"=>"intron",
		"color"=>"#000000",
		"grad_id"=>"intron",
		"shape"=>"intron_line",
		"filled"=>1,
		"stroke_width"=>1,
	);
	$exon=array(
		"name"=>"exon",
		"color"=>"<linearGradient id=\"exon_grad\" spreadMethod=\"pad\" x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"1.0\">
				<stop stop-color=\"#faf6e2\" offset=\"0\"></stop>
				<stop stop-color=\"#f4c724\" offset=\"1\"></stop>
			</linearGradient>",
		"grad_id"=>"exon",
		"shape"=>"round_corner_rectangle",
		"filled"=>1,
		"height"=>10,
	);
	$utr=array(
		"name"=>"utr",
		"color"=>"<linearGradient id=\"utr_grad\" spreadMethod=\"pad\" x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"1.0\">
				<stop stop-color=\"#ffffff\" offset=\"0\"></stop>
				<stop stop-color=\"#0000C8\" offset=\"1.0\"></stop>
			</linearGradient>",

		"grad_id"=>"utr",
		"shape"=>"rectangle",
		"filled"=>1,
		"height"=>8,
	);
	if (file_exists("task/$ran/domain_info")){
		$fgff_domain=fopen("task/$ran/domain_info","r");
		while($dline=fgets($fgff_domain)){
			if(preg_match("/^#/",$dline) or preg_match("/^\s+$/",$dline)){
				continue;
			}
			$dmatch=preg_split("/\t/",trim($dline));
			$domain_num++;
			$domain_name[$domain_num-1]=$dmatch[1];
		}
	}
$color_space = array("#e21273", "#88e506", "#f2471d", "#759A83", "#2CF2E9");
	if($domain_num){
	for($d_n=0;$d_n<$domain_num;$d_n++){
//		$c="#".((($d_n+2)%3)*4+1)."F".((($d_n+1)%3)*4+1)."F".((($d_n+0)%3)*4+1)."F";
		if($color_space[$d_n]){
			$c=$color_space[$d_n];
		}else{
			$c="#".create_random_color(6);
		}
		$domains[]=array (
			"name"=>$domain_name[$d_n],
			"color"=>"<linearGradient id=\"domain".($d_n+1)."_grad\" spreadMethod=\"pad\" x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"1.0\">
				<stop stop-color=\"#ffffff\" offset=\"0\"></stop>
				<stop stop-color=\"$c\" offset=\"1.0\"></stop>
			</linearGradient>",
			"grad_id"=>"domain".($d_n+1),
			"shape"=>"rectangle",
			"filled"=>1,
			"height"=>10,
			"height_on_intron"=>6,
			"display"=>1,
		);
	}
	}else{
		$domains=array();
	}
	$tree_width=200;
	$tree_strw=0;
	$tree_color="#000000";
}
$path="task/$ran";
$flength="$path/gene_length";
$fexon="$path/exonPos_intronPhase";
$bed="$path/for_drawing.bed";
$lresult="$path/length.result";
$svg="$path/$ran.svg";
$seq_exist=file_exists("$path/fragment_site");

$tree_exist=file_exists("$path/$ran.tree");
function create_random_color($length)
{
	srand((double)microtime()*1000000);
	$possible = "123456789"."ABCDEF";
	$authstr = "";
	while(strlen($authstr)< $length)
	{
			$authstr.=substr($possible, rand(0,strlen($possible)),1);
	}
	return $authstr;
}

function my_json_decode($jstr){
	$jstr= ltrim ($jstr,'{');
	$jstr= rtrim ($jstr,'}');
	$matches=preg_split("/,/",$jstr);
	foreach ($matches as $m) {
		$kv=preg_split("/:/",$m);
		for ($n=0;$n<2;$n++) {
			$kv[$n]= ltrim ($kv[$n],'"');
			$kv[$n]= ltrim ($kv[$n],'\"');
			$kv[$n]= rtrim ($kv[$n],'"');
			$kv[$n]= rtrim ($kv[$n],'\"');
		}
		if(preg_match("/^\d+$/",$kv[1])){
			$kv[1]=intval($kv[1]);
		}elseif(preg_match("/^\d+\.\d+$/",$kv[1])){
			$kv[1]=(float) $kv[1];
		}
		$json_obj{$kv[0]}=$kv[1];
	}
	return $json_obj;
}

#print_r ($domains);
?>
