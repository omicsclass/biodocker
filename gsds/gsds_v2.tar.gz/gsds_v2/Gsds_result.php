<?php
//display drawing result 
header("X-XSS-Protection: 0");
include("head.php");
?>
<link rel="stylesheet" type="text/css" href="gsds_css/result.css">
<link type="text/css" rel="stylesheet" href="svg-edit-2.6/jgraduate/css/jgraduate.css">
<link type="text/css" rel="stylesheet" href="svg-edit-2.6/jgraduate/css/jPicker.css">
<script type="text/javascript" src="svg-edit-2.6/jgraduate/jpicker.min.js"></script>
<script type="text/javascript" src="svg-edit-2.6/jgraduate/jquery.jgraduate.js"></script>
<script type="text/javascript" src="gsds_js/color_select.js"></script>
<script type="text/javascript" src="gsds_js/result.js"></script>
<div id="page">
<?php 
echo "<p>";
$ran=$_GET['ran'];
$file=$_GET['file'];
$tree_s=$_GET['tree_s'];
$scale=$_GET['scale'];
$width=$_GET['width'];
$img_height=$_GET['img_height'];
$intron_color=$_GET['intron_color'];
$intron_color=urldecode($intron_color);
$intron_color=stripslashes($intron_color);
$exon_name=$_GET['exon_name'];
$exon_color=$_GET['exon_color'];
$exon_color=urldecode($exon_color);
$exon_color=stripslashes($exon_color);
$utr_color=$_GET['utr_color'];
$utr_color=urldecode($utr_color);
$utr_color=stripslashes($utr_color);
$domain_num=$_GET['domain_num'];
$domain_name=$_GET['domain_name'];
$domain_name=base64_decode($domain_name);
$domain_name=unserialize($domain_name);
$domain_color=$_GET['domain_color'];
$domain_color=base64_decode($domain_color);
$domain_color=unserialize($domain_color);
	for($d_n=0;$d_n<$domain_num;$d_n++){
		$d_clr=urldecode($domain_color[$d_n]);
		$d_color[]=stripslashes($d_clr);
	}
$cgi_warning=$_GET['cgi_warning'];
$cgi_warning=base64_decode($cgi_warning);
$cgi_warning=unserialize($cgi_warning);
$domain_on_intron=$_GET['domain_on_intron'];

$high=20;  // should equal to the high in page Gsds_structure.php
$idlength=100; // should equal to the length of id in page Geds_structure.php

$path="task/$ran";
$f_noid="$path/no.id";
$f_more_gene="$path/more_gene_position";
$more_id_num=0;
?>
<script type='text/javascript'>
window.onload=function(){(document.getElementById('result_iframe_container').style.height="<?php echo ($img_height+45);?>"+'px');};
</script>
<script type='text/javascript'>
$(function() {
$('#intron_clr_button').click(function(){color_select('intron');}); 
$('#exon_clr_button').click(function(){color_select('exon');}); 
$('#utr_clr_button').click(function(){color_select('utr');}); 
$('#tree_clr_button').click(function(){color_select('tree');}); 
$('#intron_rescale').click(function(){
	if(this.checked){
		$('#intron_shape option:contains("hat")').prop('selected', true);
	}
});

<?php
//set parameters for other features 
for($d_num=0;$d_num<$domain_num;$d_num++){
	echo "$('#domain".($d_num+1)."_clr_button').click(function(){
		color_select('domain".($d_num+1)."');});\n";
		$t='domain'.($d_num+1); 
		echo "$('#domain_display_$t').click( function(){
			hid=$('#domain_displayHid_$t');
			if(hid.attr('value')!=0){
				hid.attr('value',0);
			}else{
				hid.attr('value',1);
			}
	});\n";
}
?>
});
<?php if ($domain_on_intron){?>
	domain_on_intron=1;
<?php }else{?>
	domain_on_intron=0;
<?php }?>	
	intron_alerted=0;
	hat_alerted=0;
</script>
<div id="result" > 
<?php 
if ($cgi_warning){
	foreach($cgi_warning as $w){
?>
	<p class="waring">Warning: <?php echo $w?></p>
<?php 
	}
}
?>
<div id="result_iframe_container">
<div id="loading_tip">Redrawing...</div>
<?php 
echo "<iframe id='result_iframe' name='result_iframe' frameborder=0 height=100% width=100% src=\"Gsds_svg_container.php?ran=$ran&width=$width&img_height=$img_height\"></iframe>";
?>
</div>
</div>
<div id="edit_button_line">
<div id="submit_button_line">
	<div id="submit_button" class="mybutton form_button">Redraw</div>
	<div id="pre_button" class="mybutton form_button">Undo all</div>
</div>
<a href="Gsds_svg_edit_pass.php?ran=<?php echo $ran;?>"><div id="SVG_edit" class="edit_button" title="Edit figure with SVG-edit">Edit figure interactively</div></a>
<span id='save_as'>Save as:</span>
<a href="<?php echo "$path/$ran";?>.svg" target="_blank"><div id="SVG_download" class="edit_button export_button">SVG</div></a>
<a href="Gsds_svg2png.php?ran=<?php echo $ran;?>&img_format=png" target="_blank"><div id="PNG_export" class="edit_button export_button">PNG</div></a>
<a href="Gsds_svg2png.php?ran=<?php echo $ran;?>&img_format=pdf" target="_blank"><div id="PDF_export" class="edit_button export_button">PDF</div></a>
</div>
<form id="redraw_form" action="Gsds_graph_module.php" method="post"target="result_iframe">
<input name="redraw" type="hidden" value=1 \>
<input name="ran" type="hidden" value="<?php echo $_GET['ran']?>" \>
<input name="width" type="hidden" value="<?php echo $_GET['width']?>" \>
<input name="color" type="hidden" value="<?php echo $_GET['color']?>" \>
<input name="file" type="hidden" value="<?php echo $_GET['file']?>" \>
<input name="tree_s" type="hidden" value="<?php echo $_GET['tree_s']?>" \>
<input name="cgi_info" type="hidden" value="<?php echo $_GET['cgi_info']?>" \>
<div id="display_conf">
<?php 
printFeatureConf("intron","Intron",$intron_color,4,0);
printFeatureConf("exon","exon",$exon_color,10,0);
printFeatureConf("utr","UTR",$utr_color,8,0);
for($d_num=0;$d_num<$domain_num;$d_num++){
	printFeatureConf("domain".($d_num+1),$domain_name[$d_num], $d_color[$d_num],10,1);
}
?>
<?php 
//tree config
if($_GET['tree_s']){
?>



<div id="tree_featureConf" class="featureConf">
<div class="feature_name">
Phylogenetic tree
</div>
<div class="conf_content">
	<div id=tree_colorSelector" class="colorSelector">
		<div class="color_name">Color</div>
		<input name="tree_color" id="tree_color" type="hidden" value="#000000">
		<div id="tree_gradPicker" class="gradPicker"></div>
		<div id="tree_clr_button" class="clr_button" style="background-color:#000000">
		<svg xmlns="http://www.w3.org/2000/svg" height="20px" width="40px" id="tree_svg">
			<linearGradient id="tree_grad" spreadMethod="pad" x1="0.0" y1="0.0" x2="0.0" y2="1.0">
				<stop stop-color="#ffffff" offset="0"></stop>
				<stop stop-color="#000000" offset="1.0"></stop>
			</linearGradient>
			<rect id="tree_rect" width="100%" height="100%" fill=#000000 />
		</svg>
		</div>
	</div>
	<div class="height">
		<div class="height_name">Tree width</div>
		<input id="tree_width" name="tree_width" class="heightSelector"  type="text" size=10 value=200 />
		<span class="px">px</span>
	</div>
	<div class="height">
		<div class="height_name">Stroke width</div>
		<input name="tree_strw" class="heightSelector"  type="text" size=10 value=1 />
		<span class="px">px</span>
	</div>
</div>

<?php 
}
?>
</div>
</form>
<div id="extra_info"></div>
<form id="pre_form" action="Gsds_undo_all.php" method="post" target="undo_hidden_iframe">
<input type="hidden" name="ran" value="<?php echo $ran;?>">
</form>
<iframe id="undo_hidden_iframe" style="display:none;"></iframe>
<?php 

// if the input file is in GI, we will list the information (start, end, species) for genes
if (file_exists($f_more_gene) && (filesize($f_more_gene)!=0)){
   $more_id_num=exec("cut -f1 $f_more_gene|sort -u |wc -l");
   $ar=array();
   $fm=fopen($f_more_gene,"r");
   while($line=fgets($fm)){
		array_push($ar,$line);
   }
	echo "The following are the gene product, CDS start and end.<br>Sometimes, a GenBank entry has more than one gene product.<br>";
	echo "<table border=1 ><tr align=center><td>ID</td><td>Species</td><td>Gene Name</td><td>Gene Start</td><td>Gene End</td></tr>";
	
	foreach ($ar as $ag){
		list($m1,$m2,$m3,$m4,$m5)=preg_split("/\t/",$ag);
		echo "<tr align=center>";
		echo "<td><a href=http://www.ncbi.nih.gov/entrez/query.fcgi?db=nucleotide&cmd=search&term=".$m1." target=_blank>".$m1."</a></td>";
		echo "<td>$m2</td>";
		echo "<td>$m3</td>";
		echo "<td>$m4</td>";
		echo "<td>$m5</td>";
		echo "</tr>";
	}
	echo "</table>";
	
}
// if no entry ID or no CDS ID, prompt it
$i=0;
if (file_exists($f_noid) && (filesize($f_noid)!=0)){
	
	$fn=fopen($f_noid,"r");
	$no_id='';
	while($line=fgets($fn)){
		$line=trim($line);
		if($no_id!=''){
			$no_id=$no_id.",".$line;
		}
		else {
			$no_id=$line;
		}
		$i++;
	}
	if ($i==1){
		$no_id_string=$no_id.": This ID is not existed in the NCBI GenBank or the entry doesn't have CDS information.";		
	}
	else {
		$no_id_string=$no_id.": These IDs are not existed in the NCBI or these entries don't have CDS information.";
	}
	echo "<p><font color=red>$no_id_string</font>";
	
}
?>
<p>
<hr></hr>
<div>

<?php 
function printFeatureConf($t,$t_n,$c,$h,$isdomain){
global $exon_name;
$c=urldecode($c);
?>
<div id="<?php echo $t;?>_featureConf" class="featureConf">
<?php 
if($isdomain){?>
	<input name="domain_name[]" type="hidden" value="<?php echo $t_n?>"/>
	<input class="domain_display" id="domain_display_<?php echo $t;?>" type="checkbox" value="1" checked=1/>
	<input id="domain_displayHid_<?php echo $t;?>" name="domain_display[]" type="hidden" value="1"/>
<?php }?>
<div class="feature_name" <?php if(!$isdomain){echo "style=\"clear:left\"";}?>>
<?php if($t=="exon"){echo $exon_name;}else{echo $t_n;}?>
</div>
<div class="conf_content">
<div id="<?php echo $t;?>_colorSelector" class="colorSelector">
<div class="color_name">Color</div>
<input name="<?php if($isdomain){echo "domain_color[]";}else{echo $t."_color";}?>" id="<?php echo $t;?>_color" type="hidden" value="<?php echo urlencode($c)?>">
<div id="<?php echo $t;?>_gradPicker" class="gradPicker"></div>
<div id="<?php echo $t;?>_clr_button" class="clr_button" 
<?php if (preg_match("/^#/",$c)){
echo "style=\"background-color:$c\"";
}else{
echo "style=\"background-color:#999999\"";
}
?>
>
		<svg xmlns="http://www.w3.org/2000/svg" height="20px" width="40px" id="<?php echo $t?>_svg">
<?php if (preg_match("/^#/",$c)){?>
			<linearGradient id="<?php echo $t;?>_grad" spreadMethod="pad" x1="0.0" y1="0.0" x2="0.0" y2="1.0">
				<stop stop-color="#ffffff" offset="0"></stop>
				<stop stop-color=<?php echo $c;?> offset="1.0"></stop>
			</linearGradient>
			<rect id="<?php echo $t;?>_rect" width="100%" height="100%" fill=<?php echo $c?> />
<?php }else{
			echo $c;
?>
			<rect id="<?php echo $t;?>_rect" width="100%" height="100%" fill="url(#<?php echo $t;?>_grad)"/>
<?php }?>
		</svg>
</div>
</div>
<?php if ($t=="intron"){?>
		<div class="shape">
		<div class="shape_name">Shape</div>
		<select id="intron_shape" name="intron_shape" class="shapeSelector">
			<option value="intron_line">Line</option>
			<option value="dashed_intron_line">Dashed line</option>
			<option value="shrinked_intron_line">Shrinked line</option>
			<option value="hat">Hat</option>
		</select>
		</div>
		<div class="height">
		<div class="height_name">Line width</div>
		<input name="intron_stoke_width"class="heightSelector"  type="text" size=10 value=1 />
		<span class="px">px</span>
		</div>
		<div class="rescale">
		<div id="rescale_name">Intron rescale</div>
		<a href="Gsds_help.php#intron_rescale"><div class="question_mark"></div></a>
		<select id="intron_rescale" name="intron_rescale">
			<option value="0" selected>
			<label>No rescale<label>
			</option>
			<option value="1" >
			<label>Shrink</label>
			</option>
			<option value="2" >
			<label>Same length for introns</label>
			</option>
		<input id="intron_zoom" name="intron_zoom" value=0.5>
		</div>
		
		<?php if($_GET["has_phase"]){?>
		<div id="phase_name">Display intron phase</div>
		<input id="intron_phase" name="intron_phase" type="checkbox" value=1>
		<?php }?>
<?php }else{?>
		<div class="shape">
		<div class="shape_name">Shape</div>
		<select name="<?php if($isdomain){echo "domain_shape[]";}else{echo $t."_shape";}?>" class="shapeSelector<?php if($isdomain){echo " domainShapeSelct";}?>">
			<option value="rectangle">Rectangle</option>
			<option value="round_corner_rectangle" <?php if($t=="exon"){echo "selected";}?>>Round-corner rectangle</option>
			<option value="wedge">Wedge</option>
			<option value="double_sided_wedge">Double sided wedge</option>
			<?php if($isdomain){?>
			<option value="point_wedge">Wedge (for single nucleotide feature)</option>
			<option value="point_arrow">Arrow (for single nucleotide feature)</option>
			<?php }?>
		</select>
		</div>
		<?php if($t!="intron"){?>
		<div class="isfilled_div">
			<div class="filled_label">Filled</div>
			<input class="isfilled" id="<?php echo $t;?>_isfilled" name="<?php echo $t;?>_isfilled" type="checkbox" value="1" checked=1/>
		</div>
		<?php }?>
		<?php if($isdomain){?>
		<div class="height">
		<div class="height_name height_ex_name">Height on exon</div>
		<input name="domain_height[]" class="heightSelector"  type="text" size=10 value=<?php echo $h;?> />
		<span class="px">px</span>
		</div>
		<div class="height height_in_div">
		<div class="height_name">Height on intron</div>
		<input name="domain_height_on_intron[]" class="heightSelector"  type="text" size=10 value=6 />
		<span class="px">px</span>
		</div>
		<?php }else{?>
		<div class="height">
		<div class="height_name">Height</div>
		<input name="<?php echo $t."_height";?>"class="heightSelector"  type="text" size=10 value=<?php echo $h;?> />
		<span class="px">px</span>
		</div>
		<?php }?>
		<?php if($isdomain){?>
		<div class="point_featureConf">
			<div class="arrow_width">
				<div class="aw_name">Arrow width</div>
				<input name="domain_aw[]" class="awSelector"  type="text" size=10 value="4" />
				<span class="px">px</span>
			</div>
			<div class="y_shift">
				<div class="ys_name">Shift</div>
				<input name="domain_ys[]" class="ysSelector"  type="text" size=10 value="0" />
				<span class="px">px</span>
			</div>
			<div class="arrow_up">
				<div class="above_name">Direction</div>
				<div class="aboveSelector">
				<input type="radio" name="<?php echo $t?>_up" value="-1" checked/><label class="aboveLabel">Down</label>
				<input type="radio" name="<?php echo $t?>_up" value="1"/><label class="aboveLabel">Up</label>
			</div>
		</div>
		</div>
		<?php }?>
<?php }
?>
</div>
</div>
<?php 
}
?>

</div>
<?php  include("foot.html"); ?>
