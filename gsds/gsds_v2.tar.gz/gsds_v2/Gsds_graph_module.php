<?php
//module to draw the figure  
 
error_reporting (E_ALL ^ E_NOTICE);
include 'Gsds_get_graph_var.php';
include 'Gsds_error_after_cgi.php';

$multi_transcript=1;

//define required functions for drawing
include 'Gsds_shape.php';
function draw_feature($type,$start,$end,$pos){
	global $scale,$struct_s;
	$type["shape"]($struct_s+($start-1)*$scale,$struct_s+$end*$scale,$pos,$type);
}
function draw_domain($type_num,$on_exon,$start,$end,$pos){
	global $scale,$struct_s,$domains,$intron,$intron_dy;
	if(preg_match("/point_/",$domains[$type_num-1]["shape"])){
			$domains[$type_num-1]["shape"]($struct_s+($start-1/2)*$scale,$end-$start+1,$scale,$pos,$domains[$type_num-1]);
	}else{
		if($on_exon){
			$domains[$type_num-1]["shape"]($struct_s+($start-1)*$scale,$struct_s+$end*$scale,$pos,$domains[$type_num-1]);
		}else{
			$d_type=$domains[$type_num-1];
			$d_type['height']=$domains[$type_num-1]["height_on_intron"];
			$domains[$type_num-1]["shape"]($struct_s+($start-1)*$scale,$struct_s+$end*$scale,$pos,$d_type);
		}
	}
}

if (!preg_match("/gff/",$file) and ($file != 'gi')){$multi_transcript=0;}
include 'Gsds_picture_layout.php';

$longest=0;

$fgff=fopen($bed,"r");
$tmp_d_off=array();

//parse the genes for drawing in the BED file
$cal_longest=escapeshellcmd("perl gcgi_bin/Gsds_cal_every_gene.pl task/$ran/for_drawing.bed");
exec($cal_longest,$cal_result);
if(!$t_num){
	$t_num=$cal_result[0];
}
$longest=$cal_result[1];
$max_ex_sum=$cal_result[2];
$max_in_num=$cal_result[3];

//deal with intron rescaling
if($intron_rescale==1){
	$cal_longest=escapeshellcmd("perl gcgi_bin/Gsds_intron_rescale_cal_longest.pl $path/for_drawing.bed $intron_zoom");
	exec($cal_longest,$in_zoom_longest);
	$in_zoom_longest=intval($in_zoom_longest[0]);
	$scale=$struct_w/$in_zoom_longest;
}else{
	if($intron_rescale==2){
		$intron_para=0.05;
		$scale=$struct_w/((1+$max_in_num*$intron_para)*$max_ex_sum);
		$intron_l=$max_ex_sum*$intron_para;
	}else{
		$scale=$struct_w/$longest;
		$intron_zoom=1;
	}
}

//set image height
if ($t_num==0){
	echo "Error! No transcript in the file!";
}
$img_height=$int_height*($t_num+4.5);
$tree_height=$int_height*$t_num;

//create a blank image
$fsvg=fopen($svg,"w");
fwrite($fsvg,"<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"$width\" height=\"$img_height\" style=\"background:#ffffff\">\n");
fwrite($fsvg,"<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$img_height\" style=\"fill:#ffffff\"/>\n");

//state the style
include 'Gsds_color_allocate.php';
$black="#000000";

//draw the tree if existed
if($tree_exist){
$tree_s=1;
include 'Gsds_draw_tree.php';
}else{
$tree_s=0;
}

//draw each transcript (line)
$tid="0";
$gid="0";
$tree_branch_num=0;
$cur_pos=0;
$last_g_pos=0;
$last_end=0;
$last_ex_end=0;
fseek($fgff,0);
while($line=fgets($fgff)){
	if(preg_match("/^#/",$line) or preg_match("/^\s+$/",$line)){
		continue;
	}
	$matches=preg_split("/\t+/",trim($line));
	
	if($matches[6] != $gid){
		$gid=$matches[6];
		$cur_pos+=$int_height;
		$matches[8]=trim($matches[8]);
		if($cgi_info['order_by_gene_id'] and $tree_exist){
			$tb_shift=$cur_pos-$last_g_pos;
			if($tb_shift>=(2*$int_height)){
			foreach ($tpp as $n=>$vpp){
				foreach ($tpp[$n] as $m=>$vp){
					if($tpp[$n][$m][1]>$last_g_pos){
						$tpp[$n][$m][1]+=$tb_shift-$int_height;
					}
				}
			}
			}
		}
		if($matches[8]and($matches[8]!=".")){
			$g_name=$matches[8];
			my_string($gname_s,$cur_pos,$g_name,$id_font_size,$black);
		}else{
			my_string($gname_s,$cur_pos,$gid,$id_font_size,$black);
		}
		$last_g_pos=$cur_pos;
		$cur_pos-=$int_height;
	}

	if($matches[0] != $tid){
		$tid=$matches[0];
		$cur_pos+=$int_height;
		$last_end=0;
		$last_ex_end=0;
		$last_phase=null;
		if($matches[7]and($matches[7]!=".")){
			$t_name=$matches[7];
			my_string($tname_s,$cur_pos,$t_name,$id_font_size,$black);
		}else{
			my_string($tname_s,$cur_pos,$tid,$id_font_size,$black);
		}
		$tmp_d_off=array();
	}

		if(!preg_match("/domain_.*_on/",$matches[3])){
			if(preg_match("/domain_.*_off/",$matches[3])){
				if(!$domain_on_intron){
					$domain_on_intron=1;
				}
				$tmp_d_off[]=$matches;
			}elseif($matches[1]>$last_ex_end+1){
				if(!$intron_exists){
					$intron_exists=1;
				}
				$last_last_end=$last_end;
				if($seq_exist){
					$seq_id=$matches[0]."_".($last_ex_end+1)."_".($matches[1]-1);
					$url="fragment_seq/$seq_id";
					$url=rtrim($url);
					fwrite($fsvg, "<a xlink:href=\"$url\" target=\"_blank\">\n");
				}
				if($intron_rescale==2){
					draw_feature($intron,$last_end+1,$last_end+$intron_l,$cur_pos);
					$last_end+=$intron_l;
				}else{
					draw_feature($intron,$last_end+1,$last_end+($matches[1]-$last_ex_end-1)*$intron_zoom,$cur_pos);

					$last_end+=($matches[1]-$last_ex_end-1)*$intron_zoom;
				}
				if($seq_exist){
					fwrite($fsvg, "</a>\n");
				}
				if(preg_match("/CDS/i",$matches[3]) and preg_match("/(0|1|2)/",$last_phase)){
					if ($intron_phase){
					// add intron phase
					my_string($struct_s+$last_last_end*$scale+2,$cur_pos-6,$last_phase,$phase_font_size,$black);
					}
					if(!$redraw and !$has_phase){
						$has_phase=1;
					}
				}
				foreach ($tmp_d_off as $doff){
					$dd=preg_split("/_/",$doff[3]);
					if($domains[$dd[1]-1]["display"]){
						if($intron_rescale==1){
							draw_domain($dd[1],0,($doff[1]-$last_ex_end)*$intron_oom+$last_last_end,($doff[2]-$last_ex_end)*$intron_zoom+$last_last_end,$cur_pos);
						}elseif(!$intron_rescale){
							draw_domain($dd[1],0,$doff[1]-$last_ex_end+$last_last_end,$doff[2]-$last_ex_end+$last_last_end,$cur_pos);
						}else{
							//warning
						}
					}
				}
				$tmp_d_off=array();
			}
		}

		if(preg_match("/domain_.*_on/",$matches[3])){
			$dd=preg_split("/_/",$matches[3]);
			if($dd[2]=="on" and $domains[$dd[1]-1]["display"]){
				draw_domain($dd[1],1,$matches[1]-$last_ex_end+$last_end,$matches[2]-$last_ex_end+$last_end,$cur_pos);
			}
		}elseif($matches[3]== "UTR"){
			if(!$utr_exists){
				$utr_exists=1;
			}
			if($seq_exist){
				$seq_id=$matches[0]."_".$matches[1]."_".$matches[2];
				$url="fragment_seq/$seq_id";
				$url=rtrim($url);
				fwrite($fsvg, "<a xlink:href=\"$url\" target=\"_blank\">\n");
				draw_feature($utr,$last_end+1,$last_end+$matches[2]-$matches[1]+1,$cur_pos);
				fwrite($fsvg, "</a>\n");
			}else{
				draw_feature($utr,$last_end+1,$last_end+$matches[2]-$matches[1]+1,$cur_pos);
			}
			$last_ex_end=$matches[2];
			$last_end+=$matches[2]-$matches[1]+1;
		}elseif($matches[3]=="CDS"){
			if(!$exon_exists){
				$exon_exists=1;
			}
			if($seq_exist){
				$seq_id=$matches[0]."_".$matches[1]."_".$matches[2];
				$url="fragment_seq/$seq_id";
				$url=rtrim($url);
				fwrite($fsvg, "<a xlink:href=\"$url\" target=\"_blank\">\n");
				draw_feature($exon,$last_end+1,$last_end+$matches[2]-$matches[1]+1,$cur_pos);
				fwrite($fsvg, "</a>\n");
			}else{
				draw_feature($exon,$last_end+1,$last_end+$matches[2]-$matches[1]+1,$cur_pos);
			}
			$last_ex_end=$matches[2];
			$last_phase=$matches[5];
			$last_end+=$matches[2]-$matches[1]+1;
		}
}
fclose($fgff);


if($cgi_info['order_by_gene_id'] and $tree_exist){
#and multiple_transcript
	foreach($tpp as $pp){
		tree_line($pp[0][0],$pp[0][1],$pp[1][0],$pp[1][1],$tree_color,$tree_strw);
		tree_line($pp[1][0],$pp[1][1],$pp[2][0],$pp[2][1],$tree_color,$tree_strw);
	}
}

//draw bottom scale line
include 'Gsds_draw_scale_line.php';
//draw figure legend
include 'Gsds_draw_legend.php';

fwrite($fsvg,"</svg>");
if($redraw){
//redraw the figure
header("Location:Gsds_svg_container.php?ran=$ran&width=$width&img_height=$img_height"); 
}else{
include 'Gsds_save_previous.php';

$intron_color=urlencode($intron["color"]);
$exon_color=urlencode($exon["color"]);
$utr_color=urlencode($utr["color"]);
	foreach($domains as $d){
		$domain_color[]=urlencode($d["color"]);
	}
$domain_color=serialize($domain_color);
$domain_color=base64_encode($domain_color);
$domain_name=serialize($domain_name);
$domain_name=base64_encode($domain_name);
$cgi_warning=serialize($cgi_warning);
$cgi_warning=base64_encode($cgi_warning);
$cgi_info=serialize($cgi_info);
$cgi_info=base64_encode($cgi_info);
if($utr_exists){
	$exonOrCDS="CDS";
}else{
	$exonOrCDS="Exon";
}
if ($image_format=="SVG"){
header("Location:Gsds_result.php?ran=$ran&scale=$scale&img_height=$img_height&intron_phase=$intron_phase&width=$width&color=$color&file=$file&intron_color=$intron_color&exon_color=$exon_color&utr_color=$utr_color&domain_name=$domain_name&domain_color=$domain_color&domain_num=$domain_num&cgi_warning=$cgi_warning&cgi_info=$cgi_info&tree_s=$tree_s&has_phase=$has_phase&domain_on_intron=$domain_on_intron&exon_name=$exonOrCDS"); 
}else{
header("Location:Gsds_result_png.php?ran=$ran&img_height=$img_height&cgi_warning=$cgi_warning&cgi_info=$cgi_info_str&tree_s=$tree_s"); 
}
}

?>
