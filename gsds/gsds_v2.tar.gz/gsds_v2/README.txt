1) Introduction
GSDS (Gene Structure Display Server) 2.0 is designed for the visualization of gene structure (i.e., the composition and position of exons, introns) and annotated features such as conserved elements and binding sites. Users can input features either in BED, GTF/GFF3, GenBank Accession Number/GI, or FASTA sequences. After inputting these features, GSDS 2.0 will generate a high-quality figure for them. After its first generation, the figure can be futher modified by multiple functionality provided in GSDS. To facilitate evolutionary study, a phylogenetic tree can be uploaded and added on the figure. In addition, users can download the source code (http://gsds2.cbi.pku.edu.cn/source_code/gsds_v2.tar.gz) and install locally.

2) Pre-requisite (Before installing GSDS 2.0, mare sure following prequistites are installed):
a. Apache2 web server (http://www.apache.org/)
b. Perl 5.8 or later version (http://www.perl.org/get.html)
c. Perl module: SVG (http://search.cpan.org/~ronan/SVG-2.28/SVG/Manual.pm) and Bio-Phylo (http://search.cpan.org/~rvosa/Bio-Phylo-0.58/lib/Bio/Phylo.pm)
d. Bedtools (https://github.com/arq5x/bedtools2)
e. Two programs of EMBOSS (http://emboss.sourceforge.net/): est2genome and seqretsplit
f. LibRSVG (http://librsvg.sourceforge.net/download/)

3) Install GSDS 2.0

a. Change to the path for installing GSDS 2.0 and unpack the tar package.
	*************************
	cd $PATH2INSTALL_GSDS
	tar -zxvf gsds_v2.tar.gz
	*************************

b. Modify the authetification of task directories and log file 
	*****************************
	cd $PATH2INSTALL_GSDS/gsds_v2
	mkdir task, task/upload_file
	chmod 777 task/
	chmod 777 task/upload_file/
	chmod a+w gsds_log
       ******************************
c. Link CGI commands in directory gcgi_bin to the commands in your system
       **********************************************************
	cd $PATH2INSTALL_GSDS/gsds_v2/gcgi_bin
	ln -s -f <path_of_seqretsplit> seqretsplit
	ln -s -f <path_of_est2genome> est2genome
	ln -s -f <path_of_bedtools>  bedtools
	ln -s -f <path_of_rsvg-convert> rsvg-convert
	***********************************************************
d. Configure Apache2 for access GSDS 2.0
   Configure Apache2 on your server, so that the $PATH2INSTALL_GSDS/gsds_v2 can be accessed (Futher information on setting Apache2: http://httpd.apache.org/docs/2.2/sections.html).
