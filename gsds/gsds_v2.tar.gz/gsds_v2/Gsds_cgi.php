<?php
$ran=$_GET['ran'];
$intron_phase=$_GET['intron'];
$image_format=$_GET['image'];
$width=$_GET['width'];
$file=$_GET['file'];
$domain_exists=$_GET['domain_exists'];
$tree_exists=$_GET['tree_exists'];
$protein_coords=$_GET['protein_coords'];

if(!$protein_coords){
	$protein_coords=0;
}

// input data is FASTA sequence
if ($file=="fasta"){
	$e=escapeshellcmd("bash gcgi_bin/Gsds_command.sh $ran $protein_coords 0 fasta");
}
// input data in in BED format
elseif ($file=="site") {
	$e=escapeshellcmd("bash gcgi_bin/Gsds_command_site.sh $ran $protein_coords 0 site");
}
// input data is GI accesssion
elseif ($file=="gi"){
	$e=escapeshellcmd("bash gcgi_bin/Gsds_command_gi.sh $ran $protein_coords takePlaceVar gi");
}
// input data is in GTF/GFF3format
elseif (preg_match("/gff\.(\w+)(\.(\w*))?/",$file,$fmatches)) {
	$e=escapeshellcmd("bash gcgi_bin/Gsds_command_gff.sh $ran $protein_coords $fmatches[1] gff");
}
//write to run log
$ip=getenv('REMOTE_ADDR');
$date=date("Y-m-d H:i:s");
$string="$ip\t$date\t$ran\t$file\t$image_format\t$domain_exists\t$tree_exists\n";
$handle=fopen("gsds_log","a+");
fwrite($handle,$string);

$s=exec("$e");
//if the order file exists, sort output ids by the order
if(file_exists("task/$ran/$ran.order")){
	$sort_command="cd task/$ran; perl ../../gcgi_bin/Gsds_sort_file.pl for_drawing.bed $ran.order tmp_for_drawing";
	$s2=exec($sort_command,$cgi_info);
	//use cgi_info to collect error and warning messages
	$cgi_info=urlencode($cgi_info[0]);
}
header ("Location:Gsds_graph_module.php?ran=$ran&image=$image_format&intron=$intron_phase&width=$width&color=$color&file=$file&domain_name=$domain_name&domain_color=$domain_color&domain_num=$domain_num&cgi_info=$cgi_info"); 
?>
