<?php include ("head.php");?>
<link href="gsds_css/help.css" type="text/css" rel="stylesheet">
<div id="page">
	<div id="toc" class="toc">
		<div id="toctitle">Contents</div>
	<ul class="contents_list">
	<li class="toclevel-1"><a class="contents_a" href="#level1"><span class="tocnumber">1</span> <span class="toctext">Work Flow of GSDS 2.0</span></a></li>
	<li class="toclevel-1"><a class="contents_a" href="#level2"><span class="tocnumber">2</span> <span class="toctext">Supported Gene Features and Formats</span></a></li>
		<ul>
		<li class="toclevel-2"><a class="contents_a" href="#level2-1"><span class="tocnumber">2.1</span> <span class="toctext">Input Main Features</span></a></li>
			<ul>
			<li class="toclevel-3"><a class="contents_a" href="#level2-1-1"><span class="tocnumber">2.1.1</span> <span class="toctext">BED Format</span></a></li>
			<li class="toclevel-3"><a class="contents_a" href="#level2-1-2"><span class="tocnumber">2.1.2</span> <span class="toctext">GTF/GFF3 Format</span></a></li>	
			<li class="toclevel-3"><a class="contents_a" href="#level2-1-3"><span class="tocnumber">2.1.3</span> <span class="toctext">GenBank Accession Number/GI</span></a></li>	
			<li class="toclevel-3"><a class="contents_a" href="#level2-1-4"><span class="tocnumber">2.1.4</span> <span class="toctext">FASTA Sequences</span></a></li>	
			</ul>
		<li class="toclevel-2"><a class="contents_a" href="#level2-2"><span class="tocnumber">2.2</span> <span class="toctext">Add Other Features</span></a>
		</ul>
	<li class="toclevel-1"><a class="contents_a" href="#level3"><span class="tocnumber">3</span> <span class="toctext">Adding Phylogenetic Tree/Output Order</span></a>
	<li class="toclevel-1"><a class="contents_a" href="#level4"><span class="tocnumber">4</span> <span class="toctext">Modifying the Generated Figure</span></a>
	<li class="toclevel-1"><a class="contents_a" href="#level5"><span class="tocnumber">5</span> <span class="toctext">Installing a Local Version</span></a>
	</div>

<div id="back2top">
	<a href="#body_center">Back to top</a>
</div>


<h2 id="level1">1. Work Flow of GSDS 2.0</h2>
	<p>GSDS 2.0 is designed for the visualization of annotated features for genes, and the generation of high-quality figures for publication. Besides the main features (i.e., coordinates of exons/CDS), other annotated features such as conserved elements and binding sites can also be displayed. GSDS 2.0 supports features in four types of formats, including BED, GTF/GFF3, GenBank Accession Number/GI, and Sequences in FASTA. After inputting these features, GSDS would transform them into a uniform format for figure generation. To facilitate evolutionary study, a phylogenetic tree can be uploaded and displayed on the side-panel of the figure.</p>
	<img id="schema_img" src="Gsds_images/schema.png"/>
	<span id="pptx"><a href="work_flow/work_flow_of_GSDS2.0.pptx">Download high-resolution work flow in PowerPoint</a></span>
	<p>After the first generation of figures, users can turn on/off the display of specified features, and modify the sizes, shapes and colors of displayed features. Moreover, the generated figures can be sent to a built-in SVG-edit server for further refining. Finally, users can export the figure as SVG, PNG, or PDF.</p>
<h2 id="level2">2. Supported Gene Features and Formats</h2>
	<p>GSDS supports the display of main features (coordinates of exons/CDS), as well as any other features that can be described in BED formats, such as conserved elements, binding sites.</p>
	<h3 id="level2-1">2.1 Input Main Features</h3>
	<p>Users can input the main features in four formats, including BED, GTF/GFF3, GenBank Accession Number/GI, and FASTA Sequences. Brief introduction for these formats are described as following:</p>
	<h4 id="level2-1-1">2.1.1 BED Format</h4>
	<p>BED format uses the tab-separated fields to describe the annotated features (see <a href="http://genome.ucsc.edu/FAQ/FAQformat.html#format1">UCSC</a> for more details). Users can input features as following format:</p>
	<pre><font class="muss_input">geneID/transcriptID	start	end	featureType</font>	phase(optional)</pre>
	<p>The first four columns are required (marked in blue), and the last column for intron phase is optional. To display the main feature correctly, the column for feature type should include exon, CDS or UTR.</p>
	<p>Example:</p>
	<pre>AY077757	0	725	UTR	.
AY077757	725	1157	CDS	0
AY077757	1287	1757	CDS	2
AY077757	1867	1993	CDS	2
AY077757	2143	2303	CDS	0
AY077757	2303	2731	UTR	.</pre>
	<p>Note: the coordinate system is <font color="red">zero-based</font> in BED format.</p>
	<h4 id ="level2-1-2">2.1.2 GTF/GFF3 Format</h4>
	<p>The <a href="http://genome.ucsc.edu/FAQ/FAQformat#format4">GTF</a>/<a href="http://www.sequenceontology.org/gff3.shtml">GFF3</a> is widely used to describe gene features, which contains 9 columns per line.</p>
	<pre><font class="muss_input">seqID</font>	source	<font class="muss_input">featureType	start	end</font>	score<font class="muss_input">	strand</font>	frame	<font class="muss_input">attributes(geneID and transcriptID required)</font></pre>
	<p>The columns in blue are required by GSDS 2.0, others are optional and can be '.', representing no value for this field.</p>
	<p>Features other than exons,introns, UTRs,CDSs will also be displayed. If gene_name/transcript_name is provided, these will be shown in the graph instead of IDs.</p>
	<p>Example for GTF (see <a href="http://genome.ucsc.edu/FAQ/FAQformat#format4">more details</a>)</p>
	<pre>chr	.	UTR	1	725	.	+	.	gene_id "AY077757"; transcript_id "AY077757.1";
chr	.	CDS	726	1157	.	+	0	gene_id "AY077757"; transcript_id "AY077757.1";
chr	.	CDS	1288	1757	.	+	2	gene_id "AY077757"; transcript_id "AY077757.1";
chr	.	CDS	1868	1993	.	+	2	gene_id "AY077757"; transcript_id "AY077757.1";
chr	.	CDS	2144	2303	.	+	0	gene_id "AY077757"; transcript_id "AY077757.1";
chr	.	UTR	2304	2731	.	+	.	gene_id "AY077757"; transcript_id "AY077757.1";</pre>
	<p>Example for GFF3 (see <a href="http://www.sequenceontology.org/gff3.shtml">more details</a>)</p>
	<pre>chr	.	gene	1	2731	.	+	.	ID= AY077757
chr	.	mRNA	1	2731	.	+	.	ID=AY077757.1;Parent=AY077757
chr	.	UTR	1	725	.	+	.	ID=utr.1.AY077757;Parent=AY077757.1
chr	.	CDS	726	1157	.	+	0	ID=cds.1.AY077757;Parent=AY077757.1
chr	.	CDS	1288	1757	.	+	2	ID=cds.2.AY077757;Parent=AY077757.1
chr	.	CDS	1868	1993	.	+	2	ID=cds.3.AY077757;Parent=AY077757.1
chr	.	CDS	2144	2303	.	+	0	ID=cds.4.AY077757;Parent=AY077757.1
chr	.	UTR	2304	2731	.	+	.	ID=utr.2.AY077757;Parent=AY077757.1</pre>
	<h4 id="level2-1-3">2.1.3 GenBank Accession Number/GI</h4>
	<p>Users can input <a href="https://www.ncbi.nlm.nih.gov/genbank/">GenBank</a> accession number or GI. GSDS can fetch the corresponding information for exon/CDS coordinates from GenBank.</p>
	<img id="genbank_example" src="Gsds_images/GenBank_example.png"/>
	<p>Example:</p>
	<pre>AY077757
AY514043
BK005038
BK005071
BK005073</pre>
	<h4 id="level2-1-4">2.1.4 FASTA Sequences</h4>
	<p>Users can input both the CDS sequences and genomic sequences in <a href="http://en.wikipedia.org/wiki/FASTA_format">FASTA</a> format. GSDS can map the CDS to genomic sequences by <a href="http://emboss.bioinformatics.nl/cgi-bin/emboss/help/est2genome">est2genome</a> and get the coordinate of CDS.</p>
	<p>Example for FASTA sequences:</p>
	<pre>>AY077757
ATGGGGGCGTTGGAGATATTAGATTACAACAACACTTTAGGAAAGAGAGACAGGGACTATGAAGTGAAGGAAGCGGCATGCATGGGAATACAAAACGCTA
GGCAGCTGCTCCAGTCCCTGACGCAGGTGCGATCTCCAGTGGTGGACGAAGAATGCGATGTCATGGCTGGCGCTGCCATATCCAAGTTTCAGAAGGTGGT
GTCACTACTGAGTCGCACTGGTCATGCACGGTTTCGTAGGAGAACGCGCAACGCTGCTGTTGCCGGTTACGCAGGCGTCTTCTTAGAGAGCTCCAACTTC
TTCAGAGAAAATTCCCAGGAGACGTCGAGGGACAGAATCGTCTCGTCGGGCCATGCTAGCCCATCTCAGTTCACGCCGACGTCCTCGTCCAAGCCTCCTC
AGTCACCTGAATTGCAGGCGATCAAATATAAGGTGTTTCCTCAAAGCTCTCGTTCCGCTGATGCGACGCCTGCCTCCAGTGACCCTGCTTCAGGAGTCCA
TCATCCAAAGCCACTTCAGATCCTTCACAGCTCCATGATGCAGCAAAGCATTCCAGAACATATACTGCGTCCAGTGGCTAGTGCTGCGTATCGGCCAACT
GCCCTTCCCCCGAATCCGTTCAACAAACAGGAGGTGGGCAGCAAGGAGGGGGTGAGCGGCCACAGTCCGGACAGTTCGTTGAGCTCAGGACCTCCGCAAT
CAACTACAACGGCGTCGTTCCCAACCATGAGTGTGCAGGATGCGAGGATAACGAGCCTGCAGAATATGAAAACAGCCGAGCAACCTTCGGCGTTGCCCCC
TCGCCCGCAGCCACCAACTCCCAAGAAAAAGTGCTCCGGGCAATCCGATGAGAACGGTGCAACTTGCGCAATCCTTGGCCGCTGCCATTGTTCAAAACGC
AGGAAATTGCGGTTGAAGAGGACAATCACGGTTCGAGCAATCAGCAGCAAGTTGGCTGATATACCTTCGGATGAGTATTCATGGCGTAAGTATGGCCAGA
AGCCTATCAAAGGATCACCACATCCGAGAGGATACTACAAGTGCAGCAGCATACGAGGCTGTCCAGCGAGAAAACACGTAGAGCGGTCAATGGAAGACTC
ATCTATGTTGATTGTGACATACGAAGGCGATCATAACCATCCGCAATCGTCATCTGCTAATGGCGGATTAACAGTGCAGTCGCAATAG
	</pre>
	<p>Note: <font color="red">both the genomic sequences and CDS sequences are required.</font></p>
	<h3 id="level2-2">2.2 Add Other Features</h3>
	<p>After inputting the main features, users can add other features in BED format as following:</p>
	<pre>geneID/transcriptID	start	end	featureType</pre>
	<p>Example for other features:</p>
	<pre>AY077757	1928	1993	feature1
AY077757	2143	2261	feature1
AY514043	1062	1127	feature1
AY514043	1224	1342	feature2
BK005038	153	252	feature1
BK005038	1677	1851	feature1
BK005038	2464	2529	feature1
BK005038	2563	2729	feature2
BK005071	768	833	feature1
BK005071	927	1045	feature1
BK005073	1258	1435	feature1
BK005073	1777	1842	feature1
BK005073	1938	2050	feature2</pre>

<h2 id="level3">3 Adding Phylogenetic Tree/Output Order</h2>
	<p>To facilitate evolutionary study, users can upload a phylogenetic tree for inputted genes in <a href="http://en.wikipedia.org/wiki/Newick_format">NEWICK</a> format. GSDS will display it on the side-panel of gene features in the figure.</p>
	<p>Example for phylogenetic tree:</p>
	<pre>(((AY514043,BK005071),BK005073),(AY077757,BK005038));</pre>
	<p>Note: A semicolon is required at the end of the tree. Branch lengths are ignored in GSDS.</p>
	<br/>
	<p>Or choose the "output order" to adjust the output order of genes as following:</p>
	<pre>BK005038
BK005071
BK005073
AY077757
AY514043</pre>
	<p>if output order is provided, only the genes/transcripts included will be displayed.</p>
<h2 id="level4">4. Modifying the Generated Figure</h2>
<p>Example for result page:</p>
<img id="result_page_ex" src="Gsds_images/result_page.png"/>
<p>After the first generation of the figure, users can modify it by setting on the "region 4" in the result page, including turning off the display of specified features, modifying the color, shape, and size of the features, as well as rescaling the intron.</p>
<p>There are three options for "Intron rescale"</p>
<ul id="intron_rescale" class="text_list">
	<li>No rescale: dispalying introns in the same scale with exons.</li>
	<li>Shrink: shrinking the length of the intron. In this case, a ratio should be specified, e.g., 0.01 means to shrink intron length to 1% of its original length.</li>
	<li>displaying all introns in the same length. In this case, features on intron would not be displayed.</li>
</ul>
<p>Besides that, users can also send the generated figure to the built-in <a href="https://code.google.com/p/svg-edit/">SVG-editor</a> for further refining by clicking "Edit figure interactively".</p>
<p>Finally, users can save the figure as SVG, PNG, or PDF.</p>

<h2 id="level5">5. Installing a Local Version</h2>
<p>
Users can download the source code of GSDS 2.0 <a href="source_code/gsds_v2.tar.gz">here</a>, and install it locally(<a href="LICENSE">license</a>). See <a href="README.txt">manual</a> for more information.
</p>




</div>
<?php include ("foot.html")?>
