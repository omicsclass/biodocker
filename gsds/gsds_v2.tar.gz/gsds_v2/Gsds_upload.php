<?php 
// generate random name for this file and session
function create_random($length)
{
	srand((double)microtime()*1000000);
	$possible = "123456789"."ABCDEFGHIJKLMNPRSTUVWXYZ";
	$authstr = "";
	while(strlen($authstr)< $length)
	{
			$authstr.=substr($possible, rand(0,strlen($possible)),1);
	}
	return $authstr;
}
// upload file and check the file size
function upload_file($file,$type,$data,$file_dir){
	$filename=$file_dir.".".$type;
	# upload file
	if ($file=="Y"){
		if(!move_uploaded_file($data,$filename)){
			return false;
		}
	}
	// input text
	elseif ($file=="N"){
		$fd=fopen("$filename","w");
		fwrite($fd,$data);
		fclose($fd);
	}
	
	// check the file size
	// for gi files, the upload file cannot >1000byte with gi number <=50
	if ($type=='gi' and (filesize($filename)>1000)){
		return false;
	}
	if ($type=='seq' and (filesize($filename)>100000)){
		return false;
	}
	if ($type=='site' and (filesize($filename)>10000)){
		return false;
	}
	return true;
}
$ran=create_random(6);
// Directory to save uploaded files
$upload_dir="task/upload_file/";
$cds_seq=$_POST['text_cds'];
$gene_seq=$_POST['text_gene'];
$gi_id=$_POST['text_gi'];
$site_text=$_POST['text_site'];
$length_text=$_POST['text_length'];
$gff_text=$_POST['text_gff'];
$type=$_POST['input'];
$radio=$_POST['radio'];
$domain_name=$_POST['domain_name'];
$protein_coords=$_POST['protein_coords'];
$file_dir=$upload_dir.$ran;

// use following parameters to judge whether file uploading is successful
$up=true;
$up_s1=true;
$up_s2=true;
$up1=true;
$up2=true;

if ($type!='gi' && $type!='seq' && $type!='site' && $type!='gff'){
	$upload_error[]="<font size=4 color=red>You must select one of the 4 required input type!</font>";
}

// upload gi file or pasted data
if ($type=='gi'){
	if ($_FILES["gi"]["name"]!=""){
		$up=upload_file("Y","gi",$_FILES["gi"]["tmp_name"],$file_dir);
	}
	elseif ($gi_id!=""){
		$up=upload_file("N","gi",$gi_id,$file_dir);
	}
	else{
		$upload_error[]="No accession number or gi uploaded!";
	}
	if (!$up){
		$upload_error[]="You uploaded too many gi or accession. Please upload less than <font color=red>50</font> gene id!";
	}
}
if ($type=='seq'){
	// upload cds file or pasted data
	if ($_FILES["cds"]["name"]!=""){
		$up_s1=upload_file("Y","cds",$_FILES["cds"]["tmp_name"],$file_dir);
	}
	elseif ($cds_seq!="") {		
		$up_s1=upload_file("N","cds",$cds_seq,$file_dir);
	}
	else {
		$upload_error[]="No CDS sequence uploaded!";
	}
	if ($up_s1==false){
		$upload_error[]="Your uploaded too large file. The sequence file size limitation is <font color=red>100K and less than 50 genes</font>. Please upload or input the right GENE sequence in FASTA format!";
	}
	// upload gene file or pasted data
	if ($_FILES["gene"]["name"]!=""){	
		$up_s2=upload_file("Y","gene",$_FILES["gene"]["tmp_name"],$file_dir);
	}
	elseif ($gene_seq!=""){
		$up_s2=upload_file("N","gene",$gene_seq,$file_dir);
	}
	else {
		$upload_file[]="<font color=red>No Gene sequence uploaded!</font>";
	}
	if ($up_s2==false){
		$upload_error[]="<br>Your uploaded too large file. The sequence file size limitation is <font color=red>100K and less than 50 genes</font>. Please upload or input the right GENE sequence in FASTA format!";
	}
}

// upload BED file or pasted data
if ($type=='site'){
	if ($_FILES["site"]["name"]!=""){
		$up=upload_file("Y","site",$_FILES["site"]["tmp_name"],$file_dir);
	}
	elseif ($site_text!=""){
		$up=upload_file("N","site",$site_text,$file_dir);
	}
	else {
		$upload_error[]="<font color=red>No exon start and end file uploaded!</font>";
	}
	if ($up==false){
		$upload_error[]="Your uploaded too large file. The BED file size limitation is <font color=red>10k</font>!";
	}
}
//upload GFF file or pasted data
if ($type=='gff'){
	if ($_FILES["gff"]["name"]!=""){
		$up=upload_file("Y","gff",$_FILES["gff"]["tmp_name"],$file_dir);
	}
	elseif ($gff_text!=""){
		$gff_text=stripslashes($gff_text);
		$up=upload_file("N","gff",$gff_text,$file_dir);
	}
	else{
		$upload_error[]="Error!<br><font color=red>No gff data uploaded!</font>";
	}
	if ($up==false){
		$upload_error[]="The gff file you uploaded is too large! Please load a file less than XXXXX<br>";
	}
}

// upload domain file or pasted data
if ($_FILES["domain"]["name"]!=""){	
	$up1=upload_file("Y","domain",$_FILES["domain"]["tmp_name"],$file_dir);
}
elseif ($_POST['text_domain']!=""){
	$domain_seq=$_POST['text_domain'];
	$up1=upload_file("N","domain",$domain_seq,$file_dir);
}
if ($up1==false){
	$upload_error[]="Domain file not successfully uploaded!";
}
// upload tree file or pasted sequence
if ($_FILES["tree"]["name"]!=""){	
	$up2=upload_file("Y","tree",$_FILES["tree"]["tmp_name"],$file_dir);
}
elseif ($_POST['text_tree']!=""){
	$tree_seq=$_POST['text_tree'];
	$up2=upload_file("N","tree",$tree_seq,$file_dir);
}
// upload id order file or pasted sequence
if ($_FILES["order"]["name"]!=""){	
	$up2=upload_file("Y","order",$_FILES["order"]["tmp_name"],$file_dir);
}
elseif ($_POST['text_order']!=""){
	$order_seq=$_POST['text_order'];
	$up2=upload_file("N","order",$order_seq,$file_dir);
}
if ($up2==false){
	$upload_error[]="Tree/order file not successfully uploaded!";
}

if (!($up & $up_s1 & $up_s2 & $up1 & $up2)){
	echo "Upload file error!";
}
// image format
$image_format=$_POST['image_format'];
// image color
$color=$_POST['color'];
// need intron phase or not
$intron_phase=$_POST['intron_phase'];
// image width
$width=$_POST['width'];

// check uploaded file
$domain_name=base64_encode($domain_name);
if($upload_error){
	$upload_error=serialize($upload_error);
	$upload_error=base64_encode($upload_error);
	header("Location:Gsds_error_page.php?&ran=$ran&errors=$upload_error");
	die();
}else{
header("Location:Gsds_check_files.php?ran=$ran&image=$image_format&intron=$intron_phase&width=$width&type=$type&color=$color&radio=$radio&domain_name=$domain_name&protein_coords=$protein_coords");
}

?>
