<?php 
//the SVG frame in the result page

error_reporting (E_ALL ^ E_NOTICE);
$ran=$_GET['ran'];
$width=$_GET['width'];
$img_height=$_GET['img_height'];
$new_time=$_GET['new_time'];
$path="task/$ran";


$svg="$path/$ran.svg";
?>
<!--<link rel="stylesheet" type="text/css" href="gsds_css/Gsds_svg_container.css">-->
<div id='svg_img'>
<embed src="<?php echo "$svg?$new_time"?>" width=<?php echo $width;?> height=<?php echo $img_height;?> type='image/svg+xml' pluginspage='http://www.adobe.com/svg/viewer/install/'>
<?php 
if(file_exists("$path/fragment_site")){
?>
	<p>Click on the exon or UTR to see the correspondence sequence in a new page.</p>
<?php 
}
?>
</div>
