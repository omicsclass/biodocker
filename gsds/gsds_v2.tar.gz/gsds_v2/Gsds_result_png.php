<?php 
//draw PNG figure and display it
include("head.php");
?>
<link rel="stylesheet" type="text/css" href="gsds_css/Gsds_result_png.css">
<div id="page">
<?php 
echo "<p>";
$ran=$_GET['ran'];
$tree_s=$_GET['tree_s'];
$img_height=$_GET['img_height'];
$cgi_warning=$_GET['cgi_warning'];
$cgi_warning=base64_decode($cgi_warning);
$cgi_warning=unserialize($cgi_warning);

$path="task/$ran";
$f_noid="$path/no.id";
$f_more_gene="$path/more_gene_position";
$more_id_num=0;

$img = new Imagick();
$svg = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>'.file_get_contents("$path/$ran.svg");
$img->readImageBlob($svg);
$img->setImageFormat("png");
$img->writeImage("$path/$ran.png");
?>


<script type='text/javascript'>
window.onload=function(){(document.getElementById('result').style.height="<?php echo ($img_height+70);?>"+'px');};
</script>
<div id="result" > 
<?php 
if ($cgi_warning){
	foreach($cgi_warning as $w){
?>
	<p class="waring">Warning: <?php echo $w?></p>
<?php 
	}
}
?>
	<img id="result_img" src="/task/<?php echo "$ran/$ran";?>.png">
</div>
<?php 

// if the input file is in GI, we will list the information (start, end, species) for genes
if (file_exists($f_more_gene) && (filesize($f_more_gene)!=0)){
   $more_id_num=exec("cut -f1 $f_more_gene|sort -u |wc -l");
   $ar=array();
   $fm=fopen($f_more_gene,"r");
   while($line=fgets($fm)){
		array_push($ar,$line);
   }
	echo "The following are the gene product, CDS start and end.<br>Sometimes, a GenBank entry has more than one gene product.<br>";
	echo "<table border=1 ><tr align=center><td>ID</td><td>Species</td><td>Gene Name</td><td>Gene Start</td><td>Gene End</td></tr>";
	
	foreach ($ar as $ag){
		list($m1,$m2,$m3,$m4,$m5)=split("\t",$ag);
		echo "<tr align=center>";
		echo "<td><a href=http://www.ncbi.nih.gov/entrez/query.fcgi?db=nucleotide&cmd=search&term=".$m1." target=_blank>".$m1."</a></td>";
		echo "<td>$m2</td>";
		echo "<td>$m3</td>";
		echo "<td>$m4</td>";
		echo "<td>$m5</td>";
		echo "</tr>";
	}
	echo "</table>";
	
}
// if no entry ID or no CDS id, prompt it
$i=0;
if (file_exists($f_noid) && (filesize($f_noid)!=0)){
	
	$fn=fopen($f_noid,"r");
	$no_id='';
	while($line=fgets($fn)){
		$line=trim($line);
		if($no_id!=''){
			$no_id=$no_id.",".$line;
		}
		else {
			$no_id=$line;
		}
		$i++;
	}
	if ($i==1){
		$no_id_string=$no_id.": This ID is not existed in the NCBI GenBank or the entry doesn't have CDS information.";		
	}
	else {
		$no_id_string=$no_id.": These IDs are not existed in the NCBI or these entries don't have CDS information.";
	}
	echo "<p><font color=red>$no_id_string</font>";
	
}
?>
<p>
<hr></hr>


<?php  include("foot.html"); ?>
