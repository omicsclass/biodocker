<?php
error_reporting (E_ALL ^ E_NOTICE);
?>
<!DOCTYPE html>
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<META NAME="AUTHOR" CONTENT="Center for Bioinformatics,CBI,Peking University,Guoay">
<META NAME="DESCRIPTION" CONTENT="Gene Structure Display Server">
<META NAME="KEYWORDS" CONTENT="Gene Structure Display Server,GSDS,GSDS2,GSDS2.0,Draw Gene Structure, Gene Structure, Gene Structure diagram, Gene Structure scheme, Gene Structure schematic diagram, Gene Structure Image, Gene Structure Graph, exon, intron, UTR, phylogenetic, tree, Gene Structure Picture, Gene Structure Schematics, Gene Structure Sketch, Gene Structure Schematic, Gene Structure scheme, Exon and intron structure, domain site, intron phage, 5'UTR, 3'UTR">
<!--[if lt IE 9]>
<META http-equiv="X-XSS-Protection" content="0"/>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=IE9">
<![endif]-->
<link rel="icon" href="Gsds_images/small_logo.gif" type="image/x-icon" />
<link rel="SHORTCUT ICON" href="Gsds_images/small_logo.gif" type="image/x-icon" />
<link href="gsds_css/head.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="jquery/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="jquery/jquery-migrate-1.2.1.min.js"></script>
<title>Gene Structure Display Server 2.0</title>
</head>
<body id="main_body">
<div id="prompt">
	<span>
	Your browser doesn't support SVG. In this case, only limited function is avalable. If you would like to use the funtion for figure modification, please use Chrome 29.0, Firefox 24.0, Safari 5.1, IE 9.0 or later.
	<br>
	For IE8 or earlier, you can install <a href="http://www.google.com/chromeframe?prefersystemlevel=true">Google Chrome Frame</a> to allow smooth use.
	</span>
	<span id="close_prompt">x</span>
</div>

<div id="body_center">
	<div id="head_img">
		<a id="logo_link"  href="/">
		<span id="logo"></span>
		<div id="logo_name">Gene Structure Display Server</div>
		<!--<div id="logo_struct"></div>-->
		</a>
	</div>
	<div id="topnavLine">
		<div id="topnavMenu">
		<a class="topnav" href="index.php">Home</a>
		|
		<a class="topnav" href="Gsds_help.php">Help</a>
		|
		<a class="topnav" href="Gsds_about.php">About</a>
		|
		<a class="topnav" href="http://gsds1.cbi.pku.edu.cn">Previous version: v1.0</a>
		</div>
	</div>
