<?php
//set the layout of the figure
 
if ($width<=500){
	$width=500;
}
elseif ($width>=5000){
	$width=5000;
}

$x_edge=15;
//calculate longest id to adjust id width
exec("perl gcgi_bin/Gsds_get_display_id.pl $path/for_drawing.bed $path/gid_display $path/tid_display");
exec("wc -L < $path/gid_display |cut -f1",$gid_length);
exec("wc -L < $path/tid_display |cut -f1",$tid_length);

//if the length of ID is too long, take the value 12
$idl_limit=15;
if($gid_length[0]<=$idl_limit){
        $gidl=$gid_length[0];
}else{
        $gidl=$idl_limit;
}
if($tid_length[0]<=$idl_limit){
        $tidl=$tid_length[0];
}else{
        $tidl=$idl_limit;
}

//width for each character
$id_w=7;
$id_extr=10;
$tid_width=$id_w*$tidl+$id_extr;
if($multi_transcript){
        $gid_width=$id_w*$gidl+$id_extr;
}else{
        $gid_width=0;
}

$id_width=$gid_width+$tid_width;
$label53=20;
$tree_width=$tree_width*$tree_exist;

//width of the gene_structure
$struct_w=$width-$x_edge*2-$tree_width-$id_width-$label53*2;

//start position of the gene_structure
$struct_s=$x_edge+$tree_width+$id_width+$label53;
$gname_s=$x_edge+$tree_width;
$tname_s=$x_edge+$tree_width+$gid_width;
$int_height=20;
$scale_shift=$int_height;
$legend_shift=30;

//font sizes
$id_font_size=12;
$lgd_font_size1=15;
$lgd_font_size2=12;
$scl_font_size=10;
$phase_font_size=10;

?>
