<?php include("head.php");?>
<link href="gsds_css/index.css" type="text/css" rel="stylesheet">

<script type='text/javascript' src="gsds_js/index_main.js"></script>
<script type='text/javascript' src="gsds_js/toggle.js"></script>
<script type='text/javascript' src="gsds_js/browser_detect.js"></script>

 
<div id="page">
<form id="main_input_form" ENCTYPE="multipart/form-data"  action="Gsds_upload.php" name="form1"  method="post" >
<input type="hidden" name="max_file_size" value="1000000">
<div id="gene_input_title_line" class="input_title_line">
	<div class="input_title" id="gene_input_title">
  	<div class="must_input_ball"></div>
	<label id="gene_input_name" class="input_name">
	Gene Features
	</label>
	</div>
</div>
<div id="input_format_line" class="select_line">
	<label class="select_label" id="input_format_label">Format</label>
	<select id="input_format_selector" class="selector" name="input">
		<option value="site" selected>BED</option>
		<option value="gi">GenBank Accession Number/GI</option>
		<option value="gff">GTF/GFF3</option>
		<option value="seq">Sequence(FASTA)</option>
	</select>
</div>
	<div id="gene_input_container">

	</div>


<!--Add other features-->
<div class="additional_input">
	<div id="domain_input_title" class='input_title_line optional_InTLine' >
		<div id="domain_add_button" class="add_additional_button">
			<a id="domain_cross" class="additional_cross"></a>
			<div class="input_title">
				<div class="optional_input_ball"></div>
        		  	<a id="domain_input_name" class="input_name">
				Other Features to Display
				</a>	
			</div>
		</div>
		<a id='domain_remove_button' class='remove_additional_button' title="remove other features">
		</a>
	</div>
	<div id='domain_input_container'></div>
</div>




<!--order/tree-->
<div class="additional_input">
	<div id="order_input_title" class="input_title_line optional_InTLine">
		<div id="order_add_button" class="add_additional_button">
		<a id="order_cross" class="additional_cross"></a>
			<div class="input_title">
				<div class="optional_input_ball"></div>
				<a id="order_input_name" class="input_name">
				Output (Phylogenetic Tree/Order)
				</a>
			</div>
		</div>
		<a id='order_remove_button' class='remove_additional_button' title="remove tree/order">
                </a>
	</div>

	<div id="order_input_container"></div>
</div>

<div id="img_conf_line" class="additional_input">
	<input type="hidden" name="color" value="color">
	<input type="hidden" name="width" value="1000">
	<div id="img_format_input_title" class="input_title_line">
  	<div class="must_input_ball"></div>
	<label class="select_label">Image Format</label>
	<!--<a target="_blank" href="Gsds_help.php#level3"><div class="question_mark"></div></a>-->
	<select id="img_format_selector" name="image_format" class="selector">
		<option selected>SVG</option>
		<option >PNG</option>
	</select>
	</div>
</div>
<div id="submit_button_line">
<div id="reset_button" class="mybutton form_button">Reset</div>
<div id="submit_button" class="mybutton form_button">Submit</div>
</div>
</form>
</div>



<div id="gene_data_input_container_hidden">
<div id="gi_input" class="gene_data_input">
	<div class="data_container gene_data_container">	
		<div class="input_descr">
			Please make sure all entries input <span class="emphasized">contain mRNA fields</span> in corresponding GenBank files.
		</div>
		<div class="gene_data_title">
			<div class="data_ball"></div>
			<span class="gene_data_name">GenBank Accession Number or GI</span>
			<a target="_blank" href="Gsds_help.php#level2-1-3"><div class="question_mark"></div></a>
		</div>
	
	
		<div class="paste_data">
		<p class="load_data_choice">
		Input data
		</p>
		<textarea class="data_txt" name="text_gi" cols="30" rows="5"></textarea>
		<div id="gi_sb" class="sample_button" title="giS1">Example</div>
		</div>
		<p class="load_data">
		or upload file:
		<input name="gi" type="file" size="40">
		</p>
		</div>
	</div>



<div id="site_input" class="gene_data_input">
	<div class="data_container gene_data_container">
		<div class="gene_data_title">
		<div class="data_ball"></div>
		<span class="gene_data_name">Input features in BED format</span>
		<a target="_blank" href="Gsds_help.php#level2-1-1"><div class="question_mark"></div></a>:
		</div>
	
		<div class="paste_data">
		<p class="load_data_choice">Input data:</p>
  		<textarea class="data_txt" name="text_site" cols="40" rows="5"></textarea>
		<div class="sample_button" title="siteS1">Example</div>
		</div>

		<p class="load_data">
		or upload file:
		<input name="site" type="file" size="40"></td>
		</p>
	</div>

</div>

<div id="gff_input" class="gene_data_input">
	<div class="data_container gene_data_container">
		<div class="gene_data_title">
		<div class="data_ball"></div>
		<span class="gene_data_name">Input features in GTF/GFF3 format</span>
		<a target="_blank" href="Gsds_help.php#level2-1-2"><div class="question_mark"></div></a>
		</div>

                <div class="paste_data">
		<p class="load_data_choice">Input data:</p>
		<textarea class="data_txt" name="text_gff" id="text_gff" cols="60" rows="5"></textarea>
		<div class="sample_button" title="gffS1" >Example</div>
		</div>

		<p class="load_data">
		or upload file:
		<input name="gff" id="gff" type="file" size="40">
		</p>
	</div>
</div>

<div id="seq_input" class="gene_data_input">

	<div class="data_container gene_data_container">
	<div class="input_descr">
	Please keep the sequence IDs consistent in the two fields.
	</div>
		<div class="gene_data_title">
	  		<div class="data_ball"></div>
			<span class="gene_data_name">CDS sequence (FASTA)</span>
			<a target="_blank" href="Gsds_help.php#level2-1-4"><div class="question_mark"></div></a>
		</div>
                <div class="paste_data">                
		<p class="load_data_choice">Input data:</p>
		<textarea id="seq_data_txt1" class="data_txt" name="text_cds" cols="40" rows="5"></textarea>
		<div class="mybutton sample_button" title="seqCdsS1">Example</div>
		</div>
                <p class="load_data">
		or upload file:
		<input name="cds" type="file" size="40">
                </p>

		<div class="gene_data_title">
	  		<div class="data_ball"></div>
			<span class="gene_data_name">Genomic sequence (FASTA)</span> <a href="Gsds_help.php#level2-1-4"><div class="question_mark"></div></a>
		</div>
                <div class="paste_data">                
		<p class="load_data_choice">Input data:</p>
		<textarea id="seq_data_txt2" class="data_txt" name="text_gene" cols="40" rows="5"></textarea>
		<div class="sample_button" title="seqGeneS1">Example</div>
		</div>
                <p class="load_data">
		or upload file:
  		<input name="gene" type="file" size="40">
                </p>
	</div>

</div>
</div>

<div id="domain_input_hidden" class="additional_input_hidden">
	<div id="domain_data" class="additional_data">
		<div id="domain_scents" class="domain_scents">
		<!--<span class="additional_input_descr">Format: ID start end feature_name </span>-->
			<div id="domain_dc1" class="data_container domain_data_container">
	  			<div class="data_ball"></div>
				<span class="gene_data_name">Add other features in BED format</span>
				<a target="_blank" href="Gsds_help.php#level2-2"><div class="question_mark"></div></a>
				<p class="load_data_choice">Input data: &nbsp; &nbsp;
				<input id='protein_coords' name='protein_coords' type='checkbox' value=1 />Coordinates on proteins</p>
		    		<textarea class="data_txt" name="text_domain" id="text_domain1" cols="40" rows="5"></textarea>
				<div class="sample_button" id='ds_button' title="domainS1">Example</div>
				<p class="load_data">
				or upload file:
				<input name="domain"  type="file" size="40">
				</p>
			</div>
		</div>
	</div>
</div>

<div id="order_input_hidden" class="additional_input_hidden">
	<div id="order_data" class="additional_data">
		<div id="order_input_menu">
		<!--
		<div id="tree_order_tag" class="order_button" >Tree</div>
		<div id="id_order_tag" class="order_button" >Output order</div>
		-->
		<input id="tree_order_tag" type="radio" name="order_type" checked /><span class="order_button" onclick="javascript:$('#tree_order_tag').click();">Tree</span>
		<input id="id_order_tag" type="radio" name="order_type"/><span class="order_button" onclick="javascript:$('#id_order_tag').click();">Output order</span>
		</div>

		<div id="order_container"></div>
	</div>

		<div id="order_container_hidden">
		<div id="tree_order_container" class="data_container">
	  		<div class="data_ball"></div>
			<span class="gene_data_name">Tree file in Newick format</span>
			<a target="_blank" href="Gsds_help.php#level3"><div class="question_mark"></div></a>
			<p class="load_data_choice">Input data:</p>
	    		<textarea class="data_txt" name="text_tree" cols="40" rows="5"></textarea>
			<div class="sample_button" title="treeS1">Example</div>
			<p class="load_data">
			or upload file:
			<input name="tree" type="file" size="40">
			</p>
		</div>

		<div id="id_order_container" class="data_container">
	  		<div class="data_ball"></div>
			<span class="gene_data_name">Output order of genes(sorted by IDs)</span>
			<a target="_blank" href="Gsds_help.php#level3"><div class="question_mark"></div></a>
			<p class="load_data_choice">Input data:</p>
	    		<textarea class="data_txt" name="text_order" cols="40" rows="5"></textarea>
			<div class="sample_button" title="orderS1">Example</div>
			<p class="load_data">
			or upload file:
			<input name="order" type="file" size="40">
			</p>
		</div>
		</div>
</div>


<div id="data_sample">
<?php include("data_sample.html");?>
</div>
<div id="citation">
How to Cite:
</div>
<div id="citation_content">
Bo Hu, Jinpu Jin, An-Yuan Guo, He Zhang, Jingchu Luo and Ge Gao. (2015). <a href="http://bioinformatics.oxfordjournals.org/content/31/8/1296.full" target="_blank">GSDS 2.0: an upgraded gene feature visualization server</a>. <i>Bioinformatics</i>, 31(8):1296-1297.<br/><br/>
</div>
<?php include("foot.html");?>
