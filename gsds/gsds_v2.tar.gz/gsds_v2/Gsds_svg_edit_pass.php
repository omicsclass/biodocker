<?php
//transmit current task to SVG-editor
 
$ran=$_GET['ran'];
$path="task/$ran";
$svg="$path/$ran.svg";
$js="$path/svg_input.js";
$fsvg=fopen($svg,"r");
$fjs=fopen($js,"w");

$pre_string="$(function(){\$.when(
	\$.when(\$(\"#tool_source\").click()).then(\$('#svg_source_textarea').val(\"";
$post_string="\"))).then(
		\$(\"#tool_source_save\").click()
		);
		});";

fwrite($fjs,$pre_string);
while($line=fgets($fsvg)){
fwrite($fjs,addslashes(trim($line)));
}
fwrite($fjs,$post_string);
echo "<h3>Loading the editor...<h3>";
echo "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"2; URL=svg-edit-2.6/svg-editor.php?ran=$ran\">"; 
?>
