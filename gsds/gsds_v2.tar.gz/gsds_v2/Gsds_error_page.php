<?php  include("head.php");?>
<link href="gsds_css/error.css" type="text/css" rel="stylesheet">
<div id="error_box">
<?php
// report the specific error when run this task
 
$errors=base64_decode($_GET['errors']);
$errors=unserialize($errors);
foreach ($errors as $e){
?>
	<p class="error_msg"><font color="red">Error: </font><?php echo $e?></p>
<?php 
}
?>
</div>
<?php include("foot.html");?>
