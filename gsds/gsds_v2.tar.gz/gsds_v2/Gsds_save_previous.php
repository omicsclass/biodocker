<?php
//copy previous svg figure for modification
if(!$redraw){
	$copy_pre_cmd=escapeshellcmd("cp $svg $path/previous.svg");
	exec($copy_pre_cmd,$cp_pre,$cp_pre_s);
}
?>
