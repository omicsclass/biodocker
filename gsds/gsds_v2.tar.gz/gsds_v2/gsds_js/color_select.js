	var launchPicker = function(id, paint) {
		var elem=$("#"+id+"_clr_button");
		var pos = elem.position();
		$("#"+id+"_gradPicker").css({'left': pos.left, 'top': pos.top}).jGraduate(
			{ 
				paint: paint,
				window: { pickerTitle: "Pick a paint for the feature", },
			}, 
			function(p) {
				var rect=$("#"+last_clr_id+"_rect");
				var grad_id=last_clr_id+"_grad";
				rect.attr('fill-opacity', p.alpha/100);
				if (p.type == "linearGradient" || p.type == "radialGradient") {
					var oldgrad = document.getElementById(grad_id);
					if(p.type == "linearGradient"){
						var newgrad = document.importNode(p.linearGradient, true);
					}else{
						var newgrad = document.importNode(p.radialGradient, true);
					}
					newgrad.id = grad_id;
					// replace the old gradient with the new one
					var parent = oldgrad.parentNode;
if(rect.parent().attr('id') == parent.getAttribute('id')){
					var parent = oldgrad.parentNode;
					parent.replaceChild(newgrad, oldgrad);
					rect.attr('fill', "url(#"+grad_id+")");
}
					var gradString;
					if (newgrad.outerHTML){
					    gradString = newgrad.outerHTML;
					}
					else if (XMLSerializer){
					    gradString = new XMLSerializer().serializeToString(newgrad); 
					}
					gradString=encodeURIComponent(gradString);
					$("#"+last_clr_id+"_color").attr('value',gradString);
					$("#"+last_clr_id+"_clr_button").css("background-color","#999999");
				}else { // solid color
					rect.attr('fill', (p.solidColor!='none'?'#':'') +p.solidColor);
					var colorString=(p.solidColor!='none'?'%23':'') +p.solidColor;
					$("#"+last_clr_id+"_color").attr('value',colorString);
					$("#"+last_clr_id+"_clr_button").css("background-color",(p.solidColor!='none'?'#':'') +p.solidColor);
				}
			},
			function(p) {});
	};
	
	function color_select(id) { 
//hide all other gradPicker
$( ".gradPicker" ).hide();
		var paint = new $.jGraduate.Paint();
		var rect = $("#"+id+"_rect");
		var alpha = rect.attr("fill-opacity")*100 || 100;
		fill = rect.attr("fill");
		var grad = document.getElementById(id+"_grad")
		if (fill == "url(#"+id+"_grad)" && grad.tagName == "linearGradient") {
			paint = new $.jGraduate.Paint({alpha: alpha, linearGradient: grad});
		} else if(fill == "url(#"+id+"_grad)" && grad.tagName == "radialGradient") {
			paint = new $.jGraduate.Paint({alpha: alpha, radialGradient: grad});
		} else {
			paint = new $.jGraduate.Paint({alpha: alpha, solidColor: fill.substr(1)});
		}
		last_clr_id=id;
		launchPicker(id, paint); 
	}

