$(function(){var _supportsSVG = (!!document.createElementNS && !!document.createElementNS('http://www.w3.org/2000/svg', 'svg').createSVGRect);
		if (!_supportsSVG) {
			$('#prompt').show();	
			$('#close_prompt').click(function(){$('#prompt').hide();});
			//alert("Your browser doesn't support SVG!\nOnly limited function is avalable.\nPlease use Chrome 29.0, Firefox 24.0, Safari 5.1, IE 9.0 or later.");
			$('#img_format_selector option:contains("PNG")').prop('selected', true);
//			$('#img_format_selector option:contains("SVG")').attr('disabled', true);
		}
	}
);
/*
<!--Detcting svg suppport-->
<script language="JavaScript">
// Boolean variable to keep track of user's SVG support
var hasSVGSupport = false;
// Boolean to determine if we need to use VB Script method or not to find SVG support
var useVBMethod = false;

 Internet Explorer returns 0 as the number of MIME types,
   so this code will not be executed by it. This is our indication
  to use VBScript to detect SVG support.   
if (document.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#BasicStructure", "1.1")){
        hasSVGSupport = true;
}else if (!navigator.mimeTypes) {
    useVBMethod = true;
}
</script>

<script language="VBScript">
' VB Script method to detect SVG viewer in IE
' this will not be run by browsers with no support for VB Script
On Error Resume Next
If useVBMethod = true Then
    hasSVGSupport = IsObject(CreateObject("Adobe.SVGCtl"))
End If
</script>

<script language="JavaScript">
if (!hasSVGSupport) {
	alert("Sorry! Your browser does not support SVG. Only limited funcitions can be uesed.\nPlease use IE9.0, Firefox3.0, Chrome4.0, Safari3.2, Opera9.0 or higher.\nYou can also download Adobe SVG Viewer from http://www.adobe.com/devnet/svg/adobe-svg-viewer-download-area.html");
}
*/
