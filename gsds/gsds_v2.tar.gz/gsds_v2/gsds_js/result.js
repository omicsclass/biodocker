$(function(){

	$('#submit_button').click(function(){
//		document.getElementById('redraw_form').submit(); 
		$('#loading_tip').show();
		$.ajax({
			type: "POST",
			url: "Gsds_graph_module.php",
			data: $('#redraw_form').serialize(),
			success: function (data) {
			$('#loading_tip').hide();
			iframe=document.getElementById('result_iframe');
			iframe.src=iframe.src+"&new_time="+ new Date().getTime();
			//iframe.contentWindow.location.reload(true);
			}
		});

		$('#pre_button').one('click',function(){
			$.ajax({
				type: "POST",
				url: "Gsds_undo_all.php",
				data: $('#pre_form').serialize(),
				success: function (data) {
				window.location.reload();
				}
			});
		});
	});
	var $intron_rescale_warn=0;
	var $hat_warn=0;
	$('#intron_rescale').change(function() {
		if($('#intron_rescale').val()==1){
			$('#intron_zoom').show();
		}else{
	//		if($('#intron_rescale').val()==2 && $('[name="domain_name[]"]')){
			if($('#intron_rescale').val()==2 && domain_on_intron && !intron_alerted){
				alert ("Warning: Features on intron will not be displayed when intron length is ignored.");
				intron_alerted=1;
			}
			$('#intron_zoom').hide();
		}
	});
	if(domain_on_intron){
		$('#intron_shape').change(function() {
			if($('#intron_shape').val()=="hat" && !hat_alerted){
				alert("Warning: Features on intron will not be displayed when \"hat\" is chosen.");
				hat_alerted=1;
			}
		});
	}
	
	$('.domainShapeSelct').change(function() {
		if($(this).val()=='point_wedge' || $(this).val()=='point_arrow'){
			$(this).parents('.conf_content').find('.height_in_div').hide();
			$(this).parents('.conf_content').find('.height_ex_name').html('Height');
			$(this).parents('.conf_content').find('.point_featureConf').show();
		}else{
			$(this).parents('.conf_content').find('.height_in_div').show();
			$(this).parents('.conf_content').find('.height_ex_name').html('Height on intron');
			$(this).parents('.conf_content').find('.point_featureConf').hide();
		}
	});
	$('#tree_width').change(function() {
		if($(this).val()>300 || $(this).val()<50){
				alert ("Warning: tree width should be between 50px and 300px"); 
		$(this).val("200");
		}
	});



});

