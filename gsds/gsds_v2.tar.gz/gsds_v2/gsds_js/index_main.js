$(function(){

	$('#input_format_selector').change(function(){
		var format=this.value;
		var cId=format+'_input';
		var pId='gene_input_container';
		changeChild(pId,cId);
/*
		var text=$(this).find(":selected").text();
		document.getElementById('main_input_form').reset(); 
		$('#input_format_selector option:contains("'+text+'")').prop('selected', true);
*/
	});

	$('#input_format_selector option:contains("BED")').prop('selected', true);
	changeChild('gene_input_container','site_input');

/*	$('#domain_cursor').click(function(){
		toggle('additional');
	});
*/	
	initAddButton('domain');
	initAddButton('order');



	$('.sample_button').click(function() {
		inputSample(this);
	});
	$('#submit_button').click(function(){
		document.getElementById('main_input_form').submit(); 
	});
	$('#reset_button').click(function(){
		document.getElementById('main_input_form').reset(); 
	});
});
function inputSample(button) {
	title=$(button).attr('title');
	var v=$('#'+title).val();
	$(button).parent('div').children('.data_txt').val(v);
}
function clearTxt(button) {
	$(button).parent('div').children('.data_txt').val('');
}

function changeChild(pId,cId){
		var parentNode=$('#'+pId);
		parentNode.empty();
		if(cId){
			var newChild=$('#'+cId).clone();
			newChild.show();
			newChild.find('.sample_button').click(function(){inputSample(this)});
			parentNode.append(newChild);
		}
}


function enableAddButton(type){
	/*$('#'+type+'_add_button').one('click',function(){
		$(this).click(function(){
			mytoggle(type);
		});
		changeChild(type+'_input_container',type+'_data');
		if(type=='domain'){
			initAddDomain();
		}
		enableRemoveButton(type);
		$('#'+type+'_input_title').css('box-shadow',' 1px 1px 1px 1px black inset');
		$('#'+type+'_cross').show();
		//change add css
	});
*/	$('#'+type+'_add_button').off('click');
	initAddButton(type);
	$('#'+type+'_input_title').css('box-shadow','0px 2px 2px 2px lightGrey');
	$('#'+type+'_cross').hide();
	//change add css
}
function enableRemoveButton(type){
	$('#'+type+'_remove_button').show();
	$('#'+type+'_remove_button').one('click',function(){
		changeChild(type+'_input_container','');
		enableAddButton(type);
		$('#'+type+'_remove_button').hide();
	});
}
function initAddButton(type){
	$('#'+type+'_add_button').one('click',function(){
		$('#'+type+'_add_button').click(function(){
			mytoggle(type);
		});
    		var mydiv = $('#'+type+'_input_container');
		if(mydiv.css('display') == 'none'){
			mytoggle(type);
		}
		changeChild(type+'_input_container',type+'_data');
		if(type=='domain'){
			initAddDomain();
		}else if(type=='order'){
			initAddOrder();
		}
		/*
		if(type=='domain'){
			$('#'+type+'_input_name').html('Other Features to Display');
		}else if(type=='order'){
			$('#'+type+'_input_name').html('Phylogenetic Tree/Output Order');
		}
		*/
		$('#'+type+'_input_name').css('color','black');;
		$('#'+type+'_input_name').unbind('mouseenter mouseleave');
		enableRemoveButton(type);
		$('#'+type+'_input_title').css('box-shadow','1px 2px 5px 2px #D0DEDE inset');
		$('#'+type+'_cross').show();
		//change hover css
	});
	/*
	if(type=='domain'){
		$('#'+type+'_input_name').html('Add Other Features');
	}else if(type=='order'){
		$('#'+type+'_input_name').html('Add Phylogenetic Tree/Output Order');
	}
	*/
	$('#'+type+'_input_name').hover(
		function(){$(this).css('color','#00C6FB');},
		function(){$(this).css('color','black');}
	);
}
function initAddDomain(){
	var prnt=$('#domain_input_container');
	var prnt_hidden=$('#domain_input_hidden').children('#domain_data');
        var scntDiv = prnt.find('#domain_scents');
        
	prnt.find('#1st_feature_name').attr('value', 'feature1');
        prnt.find('.addScnt').click(function() {
        	i = scntDiv.find('.domain_data_container').size() + 1;
		add_domain = prnt_hidden.find('#domain_dc1').clone();
		add_domain.attr('id','domain_dc'+i);
		//add_domain.find('.remScnt_container').append('<div class="remScnt"></div>');
		add_domain.find('.feature_name_line').append('<div class="remScnt" title="remove feature">X</div>');
		add_domain.find('.remScnt').click(function (){
                        $(this).parents('.domain_data_container').remove();
                	return false;
                });
		add_domain.find("[name='domain_name[]']").attr('value',"feature"+i);
		add_domain.find("#text_domain1").attr('id',"text_domain"+i);
		add_domain.find("#ds_button").attr('id',"ds_button"+i);
		add_domain.find("#ds_button").attr('title',"domainS2");
		add_domain.find("#ds_button"+i).click(function (){
			inputSample(this);
		});
			scntDiv.append(add_domain);
                return false;
        });
}
function initAddOrder(){
	var prnt=$('#order_input_container');
	id_tag=prnt.find('#id_order_tag');
	tree_tag=prnt.find('#tree_order_tag');
	id_tag.click(function() {
		if(!prnt.find('#id_order_container').length){
			changeOrderType('id_order');
/*
			$(this).css('box-shadow','1px 2px 2px 2px #446666 inset');
			$(this).unbind('mouseenter mouseleave');
			tree_tag.css('box-shadow','-1px -2px 1px 1px #446666 inset');
			tree_tag.css('color','#000055');
			tree_tag.hover(
				function(){
					$(this).css('color','#11AACC');
					$(this).css('cursor','pointer');
				},
				function(){
				}
			);
*/
		}
	});
	tree_tag.click(function() {
		if(!prnt.find('#tree_order_container').length){
			changeOrderType('tree_order');
/*
			$(this).css('box-shadow','1px 2px 2px 2px #446666 inset');
			$(this).unbind('mouseenter mouseleave');
			id_tag.css('box-shadow','-1px -2px 1px 1px #446666 inset');
			id_tag.css('color','#000055');
			id_tag.hover(
				function(){
					$(this).css('color','#11AACC');
					$(this).css('cursor','pointer');
				},
				function(){
				}
			);
*/
		}
	});
	tree_tag.click();
}
function changeOrderType (type){
	var prnt=$('#order_input_container').find('#order_container');
	if(!prnt.find('#'+type+'_container').length){
		changeChildByObj(prnt,$('#'+type+'_container'));
	}
}
function changeChildByObj(p,c){
		p.empty();
		if(c){
			var newChild=c.clone();
			newChild.show();
			newChild.find('.sample_button').click(function(){inputSample(this)});
			p.append(newChild);
		}
}

