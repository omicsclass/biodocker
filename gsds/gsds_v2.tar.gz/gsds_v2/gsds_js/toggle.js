function mytoggle(type){
    var mydiv = $('#'+type+'_input_container');
    if(mydiv.css('display') == 'none'){
	mydiv.css('display','block');
	$('#'+type+'_input_title').css('box-shadow','1px 2px 5px 2px #D0DEDE inset');
	$('#'+type+'_cross').css('background-image',"url('Gsds_images/minus.gif')");
    }else{
	mydiv.css('display','none');
	$('#'+type+'_input_title').css('box-shadow','0px 2px 2px 2px lightGrey');
	$('#'+type+'_cross').css('background-image',"url('Gsds_images/plus.gif')");
    }
}
