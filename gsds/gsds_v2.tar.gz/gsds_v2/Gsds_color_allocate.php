<?php
// assign colors for types of features 
$black='#000000';
$intron["solid"]=test_solid($intron);
$exon["solid"]=test_solid($exon);
$utr["solid"]=test_solid($utr);
if(!preg_match("/^#/",$tree_color)){
	fwrite($fsvg, $tree_color);
}
for($d_n=0;$d_n<$domain_num;$d_n++){
	$domains[$d_n]["solid"]=test_solid($domains[$d_n]);
}
function test_solid($t){
	global $fsvg;
	if(preg_match("/^#/",$t["color"])){
		$solid=1;
	}else{
		fwrite($fsvg, $t["color"]);
		$solid=0;
	}
	return $solid;
}
?>
