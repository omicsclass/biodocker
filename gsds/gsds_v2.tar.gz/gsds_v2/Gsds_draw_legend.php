<?php 
// draw the figure legends

$lgd_st=$gname_s;  // the legend start 
$lgd_len=20;
$lgd_int=70;
$lgd_y=$int_height*$t_num+$scale_shift+$legend_shift;
my_string($lgd_st,$lgd_y,"Legend:",$lgd_font_size1,$black);
$lgd_y+=$int_height;
$lgd_str_y=$lgd_y;
$graph2text=5;

// exon 
if($exon_exists){
$exon["shape"]($lgd_st,$lgd_st+$lgd_len,$lgd_y,$exon);
	if($utr_exists){
		$exon_str="CDS";
	}else{
		$exon_str="Exon";
	}
my_string($lgd_st+$lgd_len+$graph2text,$lgd_str_y,$exon_str,$lgd_font_size2,$black);
$lgd_st+=$lgd_int;
}

// 5' and 3' UTR
if($utr_exists){
$utr["shape"]($lgd_st,$lgd_st+$lgd_len,$lgd_y,$utr);
if($file=="fasta"){
                $utr_string="upstream/ downstream";
        }else{
                $utr_string="UTR";
        }
my_string($lgd_st+$lgd_len+$graph2text,$lgd_str_y,$utr_string,$lgd_font_size2,$black);
        if($file=="fasta"){
                $lgd_st+=($lgd_int+90);
        }else{
                $lgd_st+=$lgd_int;
        }
}

// intron
if($intron_exists){
$intron["shape"]($lgd_st,$lgd_st+$lgd_len,$lgd_y,$intron);
my_string($lgd_st+$lgd_len+$graph2text,$lgd_str_y,"Intron",$lgd_font_size2,$black);
$lgd_st+=$lgd_int;
}

// domain
for($d_num=0;$d_num<$domain_num;$d_num++){
	if($domains[$d_num]["display"]){
	if(preg_match("/point_/",$domains[$d_num]["shape"])){
			$domains[$d_num]["shape"]($lgd_st+10,1,$scale,$lgd_y,$domains[$d_num]);
	}else{
	$domains[$d_num]["shape"]($lgd_st,$lgd_st+$lgd_len,$lgd_y,$domains[$d_num]);
	}
	my_string($lgd_st+$lgd_len+$graph2text,$lgd_str_y,$domains[$d_num]["name"],$lgd_font_size2,$black);
	$lgd_st+=$lgd_int+10;
	}
}

// intron phase
if ($intron_phase){
	my_string($lgd_st,$lgd_str_y,"0 1 2: intron phase",$lgd_font_size2,$black);
	$lgd_st+=$lgd_int+30;
}
?>
