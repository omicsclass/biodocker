<?php 
// add the scale line on the bottom of the feature
my_string($struct_s-$label53+7,$cur_pos+$scale_shift/2,"5'",$scl_font_size,$black);
my_string($width-$label53-$x_edge+5,$cur_pos+$scale_shift/2,"3'",$scl_font_size,$black);

// deal with intron rescaling
if($intron_rescale==2){
	$longest2=((1+$max_in_num*$intron_para)*$max_ex_sum);
	list($bar,$bar_str,$unit)=cal_bar($longest2);
	my_line($struct_s,$cur_pos+$scale_shift+5,$struct_s+$bar*$scale,$cur_pos+$scale_shift+5,$black,0);
	my_string($struct_s+$scale*$bar-5,$cur_pos+$scale_shift+10,$bar_str.$unit,$scl_font_size,$black); 
}elseif($intron_rescale==1){
	list($exon_bar,$exon_bar_str,$exon_unit)=cal_bar($in_zoom_longest);
	$scale_x_shift=$struct_w/5;
	$scale_exon=$exon;
	$scale_exon['height']=4;
	$scale_exon['shape']($struct_s,$struct_s+$exon_bar*$scale,$cur_pos+$scale_shift+5,$scale_exon);
	my_string($struct_s+$scale*$exon_bar-5,$cur_pos+$scale_shift+10,$exon_bar_str.$exon_unit,$scl_font_size,$black); 
	list($intron_bar,$intron_bar_str,$intron_unit)=cal_bar($in_zoom_longest-$max_ex_sum);
	$intron_bar_str/=$intron_zoom;
	intron_line($struct_s+$scale_x_shift,$struct_s+$intron_bar*$scale+$scale_x_shift,$cur_pos+$scale_shift+5,$intron);
	my_string($struct_s+$scale*$intron_bar-5+$scale_x_shift,$cur_pos+$scale_shift+10,$intron_bar_str.$intron_unit,$scl_font_size,$black); 

}else{

my_line($struct_s,$cur_pos+$scale_shift,$struct_s+$struct_w,$cur_pos+$scale_shift,$black,0);
// print the 5' and 3' label
// define the rule bar
if ($longest<=1000){
	$bar=100;
	$rule_num=$longest/$bar;
}
elseif($longest>1000 && $longest<2000){
	$bar=200;
	$rule_num=$longest/$bar;
}
elseif($longest>=2000 && $longest<5000){
	$bar=500;
	$rule_num=$longest/$bar;
}
elseif($longest>=5000){
	$bar=1000;
	$rule_num=$longest/$bar;
}
// print the bar and scale


for($k=0;$k<=$rule_num;$k++){
	// print the rule bar
   my_line($struct_s+$scale*$bar*$k,$cur_pos+$scale_shift,$struct_s+$scale*$bar*$k,$cur_pos+$scale_shift-$int_height/4,$black,0);
   // print the rule number
   if ($k==0){
	   $bp=0;
   }  
   else{
	   if ($bar==100 || $bar==200 || $bar==500){$bp=$bar*$k;}
	   if ($bar==1000){$bp=$k;}
   }
   // print the bar scale
   if ($bar==100 || $bar==200 || $bar==500) {
	   my_string($struct_s+$scale*$bar*$k-5,$cur_pos+$scale_shift+5,$bp."bp",$scl_font_size,$black);
   }
   elseif ($bar==1000){
	   my_string($struct_s+$scale*$bar*$k-5,$cur_pos+$scale_shift+5,$bp."kb",$scl_font_size,$black); 
   }
}
}


function cal_bar($l){
if (($l%10)==0){
		$l+=1 ;
	}
	$n = intval(log($l)/log(10));
	if ($l/pow(10,$n)>=3.1){
		$n++;
	}
	$bar = pow(10,($n-1));

	if ($bar<1000) {
		$bar_str=$bar;
		$unit="bp";
	}else{
		$bar_str=$bar/1000;
		$unit="kb";
	}
return array($bar,$bar_str,$unit);
}
?>
