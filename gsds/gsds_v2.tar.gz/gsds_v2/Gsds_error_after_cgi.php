<?php
//parse the error information and then report it on the page
 
$cgi_error=array();
$cgi_warning=array();
if($file=='fasta'){
	if (!file_exists($fexon) or !file_exists($flength)){
		$cgi_error[]="The CDS sequences do not match the gene sequences.";
	}elseif(!filesize($fexon) or !filesize($flength)){
		$cgi_error[]="The CDS sequences do not match the gene sequences.";
	}
}elseif($file=='gi'){
	if (!file_exists($bed)){
		$cgi_error[]="Something wrong with the NCBI GI or Accession Number. The sequence is too long or the entry has no mRNA features.";
	}
}elseif($file=='site'){
	if (!file_exists($bed)){
		$cgi_error[]="BED file parsing error.";
	}elseif(!filesize($bed)){
		$cgi_error[]="BED file parsing error.";
	}
}elseif(preg_match("/gff/",$file)){
	if (!file_exists($bed)){
		$cgi_error[]="GFF file parsing error.";
	}elseif(!filesize($bed)){
		$cgi_error[]="GFF file parsing error.";
	}
}
if($cgi_info['error']){
	$cgi_error[]=$cgi_info['error'];
}
if($cgi_info['warning']){
	$cgi_warning[]=$cgi_info['warning'];
}

if($cgi_error){
	$cgi_error=serialize($cgi_error);
	$cgi_error=base64_encode($cgi_error);
	header("Location:Gsds_error_page.php?&ran=$ran&errors=$cgi_error");
	die();
}
?>
