#!/usr/bin/perl

## guoay 07-1-29
## get the fragment site (utr exon intron) from utr exon site
##
## the input such as
#AJ011627        1       24
#AJ011627        25      323
#AJ011627        415     511
#AJ011627        512     695

## the program should find the intron position from 324 to 414
## Input: utr_exon_pos
## Output:fragment_site

die "Error!\nUsage:\nperl Name.pl utr_exon_pos fragment_site \n" if(@ARGV != 2);
($infile,$outfile)=@ARGV;
open(IN,"<$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";

while (<IN>) {
	if(/^(\S+)\s+(\d+)\s+(\d+)/){
	$id=$1; $start=$2; $end=$3;

	if ($id eq $oldid){
		$newstart=$oldend+1;
		if ($start>$newstart){
			print OUT $id."\t".$newstart."\t".($start-1)."\n";	
		}
		print OUT $_;
	}
	else {
		print OUT $_;
	}
	$oldid=$id;
        $oldend=$end;
	}
}
