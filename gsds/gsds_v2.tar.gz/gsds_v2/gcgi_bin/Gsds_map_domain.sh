#!/bin/bash
#This script is used to map other features to corresponding genes.
#task_file=$1, protein_coordinate=$2, type=$4

if [ -e $1.domain ];
	then
	#Remove space line
	cat $1.domain |sed '/^[[:space:]]*$/d'|sed 's/^[ \t]*//' >tmp_dm1

	#Mapping coordinates on proteins to these on genes.
	if [ $2 -eq 1 ];
	then 
		bash ../../gcgi_bin/trans_protein_coordinate2gene_coordinate.sh $4	
	fi
	
	#Convert into 1-based coordinate and correct BED format
	perl ../../gcgi_bin/Gsds_site_parse.pl tmp_dm1 tmp_dm2
	
	#Deal with possible multi-transcript for one gene in GFF and GI files
	#Domain file can be either in gene ID or transcript ID, and would be converted to transcript ID
	if [ $4 = "gff" ] || [ $4 = "gi" ]
	then
	perl ../../gcgi_bin/Gsds_gff_convert_domain_id.pl tmp_dm2 for_drawing.bed
	fi

	#Convert domain information to GFF format, so that bedtools recognise the coordinate as 1-based
	perl ../../gcgi_bin/Gsds_bed2gff.pl tmp_dm2 tmp_dm3

	#Split by domain name
	awk '{print >>"domains/tmp_"$3}' tmp_dm3
fi

#Convert exon file to GFF format, so that bedtools recognise coordinate as 1-based
perl ../../gcgi_bin/Gsds_bed2gff.pl for_drawing.bed domains/tmpExon.gff

cd domains
#For each type of domain
domains=`ls |grep "tmp_"`
d_num=0
for d in ${domains[@]};do
	#Record the number of each domain
	let d_num+=1
	#Record the domain name and write the domain number and the corresponding domain name into <domain_info>
	d_name=`echo $d|sed -e 's/tmp_//'`
	echo -e $d_num"\t"$d_name >> ../domain_info
	#Use bedtools to calculate domain on the exon, write into <tmp_donex>
	../../../gcgi_bin/bedtools intersect -a $d -b tmpExon.gff|sed -e "s/\(\S\+\t\S\+\t\)\S\+\(.*\)/\1domain_$d_num\_on\2/">tmp_donex
	#Use bedtools to calculate domain on the intron, write into <tmp_doffex>
	../../../gcgi_bin/bedtools subtract -a $d  -b tmpExon.gff|sed -e "s/\(\S\+\t\S\+\t\)\S\+\(.*\)/\1domain_$d_num\_off\2/">tmp_doffex
	#Append domain file to final <for_drawing> file
	cat tmp_donex tmp_doffex|awk '{print $1"\t"$4"\t"$5"\t"$3"\t"$7"\t"$8"\t"$2"\t"$6"\t"$8}' >>../for_drawing.bed
done
cd ..

#If domain file was appended, resort it for drawing
if [ -n ${#domains[@]} ]
then
	sort -s -k7,7 -k1,1 -k2,2n for_drawing.bed >tmp
	mv tmp for_drawing.bed
fi
