#!/usr/bin/perl
#This script is used to generate ID order file from tree file

die "Error!\nUsage:\nperl Name.pl  tree_file order_file\n" if(@ARGV != 2);
($infile,$outfile)=@ARGV;
open(IN,"<$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";

while(<IN>){
	if (/:/){
		foreach my $m (/[\(|,](.*?):/g){
		$m=~s/[\s|(]//g;
		print OUT $m."\n";
		}
	}else{
		s/[\s|;]//g;
		s/[\(|\)|,]+/\n/g;
		s/^\s//;
		print OUT;
	}
}
