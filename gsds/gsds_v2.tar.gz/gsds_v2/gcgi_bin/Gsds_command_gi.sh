#!/bin/bash
# This script is used to deal with GenBank GI/Accession number, and convert them to BED format for drawing 
mkdir task/$1
cd task/$1

bash ../../gcgi_bin/Gsds_upload_other_file.sh
cp ../upload_file/$1.gi .

# Format the GI
sed 's/,/\n/g' $1.gi|sed 's/;/\n/g'|sed 's/\t\+/\n/g' |sed 's/ \+/\n/g' |sed '/^[[:space:]]*$/d'>tmp; mv tmp $1.gi

#Fetch the corresponding files from GenBank by ids
perl ../../gcgi_bin/GeSS_efetch_seq_from_genbank.pl $1.gi $1.genbank

# Check the file size
fgbsize=`ls -lS $1.genbank | awk '{print $5}'`
if [ $fgbsize -gt 300000 ]; then touch exonPos_intronPhase; touch gene_length; exit;fi

#Parse the IDs which has no entry in NCBI
grep "^Count" $1.genbank |perl -ne '/^Count = 0; QueryKey = (\S+)/; print $1;' >>no.id

#Get the sequence from GenBank file
sed '/Count/d' $1.genbank |sed '/^$/d' >$1.genbank.gb
seqret $1.genbank.gb $1.fas -sformat=gb -osformat=fasta

#Parse the GenBank file and convert it to BED format
perl ../../gcgi_bin/Gsds_genbank_parse.pl $1.genbank tmp_parsed.bed gene_start_end

#Convert feature coordinates into their coordinate on genes
perl ../../gcgi_bin/Gsds_gff_cal_every_transcript.pl tmp_parsed.bed tmp_cal.bed
bash ../../gcgi_bin/Gsds_extract_domain.sh
bash ../../gcgi_bin/Gsds_gff_cal_utr.sh
less CDS_UTR.gff|sort -s -k2,2 -k1,1 -k4,4n> tmp_sorted.gff
awk '{print $1"\t"$4"\t"$5"\t"$3"\t"$7"\t"$8"\t"$2"\t"$6"\t"$9}' tmp_sorted.gff >for_drawing.bed

#Get the sequence for genes
perl ../../gcgi_bin/GeSS_get_seq_by_id+site_use_seqret_forGI.pl $1.fas gene_start_end
cat *.gene_seq >all_gene_seq.fas
rm *.gene_seq

#Get the coordinate of UTRs, Exons, and Introns on genes
perl ../../gcgi_bin/GeSS_get_fragment_site_from_utr_exon_pos.pl for_drawing.bed fragment_site

#Get the fragment site sequence
mkdir fragment_seq
cd fragment_seq
perl ../../../gcgi_bin/GeSS_get_seq_by_id+site_use_seqret.pl ../all_gene_seq.fas ../fragment_site
cd ..

#Map other features onto the BED file, and sort it by gene order file for drawing
bash ../../gcgi_bin/Gsds_map_domain.sh
bash ../../gcgi_bin/Gsds_sort_gene_by_order_file.sh 
