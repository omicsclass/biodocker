#This script is used to copy other uploaded files including the file for other domain features, the order file, and tree file.

mv ../upload_file/$1.order .
mv ../upload_file/$1.tree .
if [	-e $1.tree ];
then
	$has_semicolon=`grep ";" $1.tree`
	if [ -n $has_semicolon ];
	then
		echo ';' >> $1.tree
	fi
fi
mv ../upload_file/$1.domain .
mkdir domains

