#!/usr/bin/perl
#This script is used to calculate the longest width for layout

die "Usage: Name.pl for_drawing_file zoom\n" if (@ARGV!=2);

($infile,$zoom)=@ARGV;
open(IN,"$infile")||die "Can't open file $infile";

my @ele;
my $gid=(0,0);
my $longest=0;
while(<IN>){
        $line=$_;
        @match=split("\t",$_);
        if($match[3]=~/^(exon|UTR|CDS)$/i){
	if($match[0] eq $tid){
		$length+=($match[1]-$last_ex_end-1)*$zoom if ($match[1]>$last_ex_end+1);
		$length+=$match[2]-$match[1]+1;
		$last_ex_end=$match[2];
	}else{
		if($tid){
			$longest=$length if ($longest<$length);
		}
		$tid=$match[0];
		($length,$last_ex_end)=(0,0);
		$exon_sum+=$match[2]-$match[1]+1;
		$length+=($match[1]-$last_ex_end-1)*$zoom if ($match[1]>$last_ex_end+1);
		$length+=$match[2]-$match[1]+1;
        }
        }
}
		if($tid){
			$longest=$length if ($longest<$length);
		}
print "$longest\n";

