#!/usr/bin/perl
#This scirpt is used to convert bed format to GTF/GFF3 format
die "Usage: Name.pl id_sorted_file pos_on_gene_file\n" if (@ARGV!=2);

($infile,$outfile)=@ARGV;
open(IN,"$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";
while(<IN>){
	chomp;
        @m=split("\t",$_);
	for ($n=0;$n<9;$n++){
		$m[$n]="." if (!defined($m[$n]));
	}
	print OUT "$m[0]\t$m[6]\t$m[3]\t$m[1]\t$m[2]\t$m[7]\t$m[4]\t$m[5]\t$m[8]\n";
}
