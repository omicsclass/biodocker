#!/usr/bin/perl

## Guoay 06-3-16

## get the exon position and intron phase from the est2genome result
## the est2genome result like this:

#Exon       332 100.0     1   332 At4g01250        1   332 At4g01250     F2N1 putative DNA-binding protein
#+Intron    -20   0.0   333   542 At4g01250   
#Exon       111 100.0   543   653 At4g01250      333   443 At4g01250     F2N1 putative DNA-binding protein
#+Intron    -20   0.0   654   837 At4g01250   
#Exon       454 100.0   838  1291 At4g01250      444   897 At4g01250     F2N1 putative DNA-binding protein

## Input: est2genome.result
## Output: exon_pos_intron_phase, utr_exon_intron.position

die "Error!\nUsage:\nperl Name.pl est2genome.result exon_pos_intron_phase utr_exon_intron.position\n" if(@ARGV != 3);

($infile, $outfile1, $outfile2)=@ARGV;

open(IN,"$infile")||die "Can't open file $infile ";
open(OUT1,">>$outfile1")||die "Can't open file $outfile1";
open(OUT2,">>$outfile2")||die "Can't open file $outfile2";
my $i=1;
while (<IN>) {
	if (/^Exon/) {
		@field=split(/\s+/,$_);
		$phase=$field[7]%3;
		print OUT1 "$field[5]\t$field[3]\t$field[4]\t$phase\n";
		# if this is the first exon, check it has UTR or not
		if ($i==1){
			if ($field[3]!=1){
				$utr_end=$field[3]-1;
				print OUT2 "$field[5]\t1\t$utr_end\n";
			}
		}
		print OUT2 "$field[5]\t$field[3]\t$field[4]\n";
		$i++;
	}
	elsif (/^\+Intron/){
		@field=split(/\s+/,$_);
		print OUT2 "$field[5]\t$field[3]\t$field[4]\n";
	}
}
