#This script is used to convert site file to BED format for drawing
 
awk '{print $1"\t"$2"\t"$3"\tCDS\t\.\t"$4>"tmp_CDS"}' exonPos_intronPhase
if test -e 3UTR || test -e 5UTR 
	then
	cat 3UTR 5UTR|awk '{print $1"\t"$2"\t"$3"\tUTR\t.\t.">"tmp_UTR"}' 
else
	perl ../../gcgi_bin/Gsds_site_cal_utr.pl exonPos_intronPhase tmp_UTR gene_length
fi
cat tmp_CDS tmp_UTR|sort -s -k1,1 -k2,2n >for_drawing.bed
awk '{print $0"\t.\t.\t."}' for_drawing.bed >tmp
mv tmp for_drawing.bed
