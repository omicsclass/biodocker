#!/usr/bin/perl
#this script is used to find and calculate the maximum value of the gene length, sum exon length, and the intron number of genes
die "Usage: Name.pl for_drawing_file\n" if (@ARGV!=1);

($infile)=@ARGV;
open(IN,"$infile")||die "Can't open file $infile";

my @ele;
my $gid=(0,0);
my ($g_longest,$t_longest,$max_in_num)=(0,0,0);
my $t_num=0;
while(<IN>){
        $line=$_;
        @match=split("\t",$_);
        if($match[3]=~/(exon|UTR|CDS)/i){
	if($match[0] eq $tid){
		$exon_sum+=$match[2]-$match[1]+1;
		$intron_num++ if ($match[1]>$last_ex_end+1);
		$last_ex_end=$match[2];
	}else{
		if($tid){
			$t_longest=$exon_sum if ($t_longest<$exon_sum);
			$max_in_num=$intron_num if ($max_in_num<$intron_num);
			$g_longest=$last_ex_end if ($g_longest<$last_ex_end);
		}
		$tid=$match[0];
		$t_num++;
		($exon_sum,$intron_num,$last_ex_end)=(0,0,0);
		$exon_sum+=$match[2]-$match[1]+1;
		$last_ex_end=$match[2];
        }
	}
}
if($tid){
	$t_longest=$exon_sum if ($t_longest<$exon_sum);
	$max_in_num=$intron_num if ($max_in_num<$intron_num);
	$g_longest=$last_ex_end if ($g_longest<$last_ex_end);
}
print "$t_num\n$g_longest\n$t_longest\n$max_in_num\n";

