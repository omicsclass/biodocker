#!/bin/bash

## Guoay 2003-11-11
## use emboss est2genome to find exon position

## do the est2genome to all the file
for file in $1/*  
  do
    echo "file=$file"
    # basename use to extract only filename from a path/filename
    id=`basename $file`
    result=`echo "$id.est2genome"`
    # use the est2genome to find the exon and intron position
    ../../gcgi_bin/est2genome $file $2/$id est2genome-result/$result -space 100 -splicepenalty 10
    # extract the exon position and intron phase from the est2genome result file into one file 
    perl ../../gcgi_bin/GeSS_get_exon_pos_intron_phase_seq_from_est2genome.pl est2genome-result/$result exonPos_intronPhase fragment_site
  done   
