#!/usr/bin/perl
# Guoay 2006-10-25
# extract cds information from genbank file

use Bio::SeqIO;
use Bio::LocationI;

die "Error!\nUsage:\nperl Name.pl genbank CDS_exon gene_length no_entry.id gene_start_end 5UTR 3UTR\n" if(@ARGV != 7);
($gb_file,$outfile1,$outfile2,$outfile3,$outfile4,$outfile5,$outfile6)=@ARGV;
open(OUT_CDS,">$outfile1")||die "Can't open file $outfile1";
open(OUT_Len,">$outfile2")||die "Can't open file $outfile2";
open(OUT_NO,">$outfile3")||die "Can't open file $outfile3";
open(OUT_Gene,">$outfile4")||die "Can't open file $outfile4";
open(OUT_5UTR,">$outfile5")||die "Can't open file $outfile5";
open(OUT_3UTR,">$outfile6")||die "Can't open file $outfile6";
open(IN,"<$gb_file")||die "Can't open file $gb_file";
my @gbid; # store  the entry id as the use uploaded
while(<IN>){
	if(/^Count = (\d+); QueryKey = (\w+)/){
		# if no entry in ncbi, print the id to OUT3
		if ($1==0){
			print OUT_NO $2,"\n";
		}
		else{
			push @gbid,$2;
		}
	}
}
#foreach my $d(@gbid){
#	print $d,"\t";
#}
my $seqio_object = Bio::SeqIO->new(-file => $gb_file);
my $j=0;  # the genbank entry number, we will use the $gbid[$j] as the entry id, maybe gi or accession,
while (my $seqobj = $seqio_object->next_seq){
my $i=0;  # the CDS number of an entry

foreach my $feature ($seqobj->top_SeqFeatures){
	if ($feature->primary_tag eq 'CDS' ){
		$i++;
	}
}
# print $i;
# no CDS,print the id to the OUT3 
if ( $i==0){
	# use the $gbid[$j] as the seq id, it may accession or gi,
	# seqobj->primary_id is the ig,  $seqobj->object_id is the accession number
	print OUT_NO $gbid[$j],"\n";
} 
elsif($i==1){
     foreach my $feature ($seqobj->top_SeqFeatures){
	# if no gene tag, use the source start and end 
	if ($feature->primary_tag eq 'gene'){
           $gstart=$feature->location->start;
           $gend=$feature->location->end;
        }
	elsif ($feature->primary_tag eq 'source'){
	   $gstart=$feature->location->start;
	   $gend=$feature->location->end;
	}
	# if there exist 5UTR or 3 UTR 
	if ($feature->primary_tag eq '5\'UTR'){
	   # the 5UTR may has more than one exon
	   foreach my $location ( $feature->location->each_Location ) {
		print OUT_5UTR $gbid[$j],"\t",($location->start-$gstart+1),"\t",($location->end-$gstart+1),"\n";
           }
        }
	if ($feature->primary_tag eq '3\'UTR'){
	   foreach my $location ( $feature->location->each_Location ) {
                print OUT_3UTR $gbid[$j],"\t",($location->start-$gstart+1),"\t",($location->end-$gstart+1),"\n";
           }
        }
	if ($feature->primary_tag eq 'CDS' ){   
	   # if use $name=$feature->get_tag_values('gene'), the $name=1 it is ture
	   # $feature->seq_id and $seqobj->object_id are the same, both are the locus

	   $glength=$gend-$gstart+1;
           print OUT_Len $gbid[$j],"\t",$glength,"\n";
	   foreach my $location ( $feature->location->each_Location ) {
		print OUT_CDS $gbid[$j],"\t",($location->start-$gstart+1) . "\t" . ($location->end-$gstart+1)."\n";
	   }
	   # print out the gene product name start and end
	   if ($feature->has_tag('gene')){
		# need to get the genus and species name
		print OUT_Gene $gbid[$j],"\t",$seqobj->species->genus," ",$seqobj->species->species,"\t",$feature->get_tag_values('gene'),"\t",$gstart,"\t",$gend,"\n";
	    }
	    else{
                if ($feature->has_tag('product')){
                    print OUT_Gene $gbid[$j],"\t",$seqobj->species->genus," ",$seqobj->species->species,"\t",$feature->get_tag_values('product'),"\t",$gstart,"\t",$gend,"\n";
                }
                else{
                    print OUT_Gene $gbid[$j],"\t",$seqobj->species->genus," ",$seqobj->species->species,"\t",$feature->get_tag_values('protein_id'),"\t",$gstart,"\t",$gend,"\n";
                }	
	    }
	}
    }
}
# more than one CDS, that is more than one gene in the entry, the sequence length should use the data in soucre column
else{
    foreach my $feature ($seqobj->top_SeqFeatures){
        if ($feature->primary_tag eq 'source'){
           $s_start=$feature->location->start;
           $s_end=$feature->location->end;
	   $glength=$s_end-$s_start+1;
	   print OUT_Len $gbid[$j],"\t",$glength,"\n";
        }
	if ($feature->primary_tag eq '5\'UTR'){
	   foreach my $location ( $feature->location->each_Location ) {
                print OUT_5UTR $gbid[$j],"\t",$location->start,"\t",$location->end,"\n";
           }
        }
        if ($feature->primary_tag eq '3\'UTR'){
	   foreach my $location ( $feature->location->each_Location ) {
                print OUT_3UTR $gbid[$j],"\t",$location->start,"\t",$location->end,"\n";
           }
        }
        if ($feature->primary_tag eq 'CDS' ){   
           if ($feature->has_tag('gene')){
                $gstart=$feature->location->start;
		# this $feature->location->start is the CDS start not the gene start
                $gend=$feature->location->end;
		# print out the gene start and end to OUT4
		print OUT_Gene $gbid[$j],"\t",$feature->get_tag_values('gene'),"\t",$gstart,"\t",$gend,"\n";
           }
	   # in the more than one gene entry, if no gene tag, use the CDS start, end as the gene start and end
	   else {
		$gstart=$feature->location->start;
		$gend=$feature->location->end;
		if ($feature->has_tag('product')){
		    print OUT_Gene $gbid[$j],"\t",$seqobj->species->genus," ",$seqobj->species->species,"\t",$feature->get_tag_values('product'),"\t",$gstart,"\t",$gend,"\n";
	        }
		else{
		    print OUT_Gene $gbid[$j],"\t",$seqobj->species->genus," ",$seqobj->species->species,"\t",$feature->get_tag_values('protein_id'),"\t",$gstart,"\t",$gend,"\n";
		}
	   }
	   # the exon start and end need not minus the gene start,because we use the source start
	   foreach my $location ( $feature->location->each_Location ) {
		print OUT_CDS $gbid[$j],"\t",$location->start."\t".$location->end."\n";
	   }
	}
    }
}
$j++;
}
