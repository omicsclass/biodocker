#!/bin/bash
# This script is used to deal with FASTA sequence and convert them to BED format for drawing
mkdir task/$1
cd task/$1
bash ../../gcgi_bin/Gsds_upload_other_file.sh
mkdir cds_file gene_file
mkdir est2genome-result

# split CDS file to each sequence a file
cp ../upload_file/$1.cds cds_file/
cd cds_file
../../../gcgi_bin/seqretsplit $1.cds <<EOF
\n
EOF
rm $1.cds
cds_seq_num=`ls|wc -l`
cd ..

# split gene file to each sequence a file
cp ../upload_file/$1.gene gene_file/
cd gene_file
../../../gcgi_bin/seqretsplit $1.gene <<EOF1
\n
EOF1
rm $1.gene
gene_seq_num=`ls|wc -l`

# if there is only one sequence for both the gene and CDS, then change their names to the same; Otherwise, make sure the paired names keep consistent
if test $cds_seq_num -eq 1 && test $gene_seq_num -eq 1
   then
	gene_file_name=`ls`
	mv ../cds_file/* ../cds_file/$gene_file_name
fi

cd ..
cp ../upload_file/$1.gene .
# calculate the gene length
perl ../../gcgi_bin/cal_seq_length.pl $1.gene gene_length

# use est2genome to map each CDS sequence to its gene sequence
../../gcgi_bin/GeSS_est2genome_get_seq.sh cds_file/ gene_file/ $1.gene

# add the region of 3' UTR to fragment site file
perl ../../gcgi_bin/GeSS_add_3UTR_to_fragment_site.pl fragment_site gene_length >tmp; mv tmp fragment_site
mkdir fragment_seq
cd fragment_seq
perl ../../../gcgi_bin/GeSS_get_seq_by_id+site_use_seqret.pl ../$1.gene ../fragment_site
cd ..

#convent file to BED format, map other feature onto them, and then sort them by gene order file
bash ../../gcgi_bin/Gsds_sitefile2bed.sh
bash ../../gcgi_bin/Gsds_map_domain.sh
bash ../../gcgi_bin/Gsds_sort_gene_by_order_file.sh 
