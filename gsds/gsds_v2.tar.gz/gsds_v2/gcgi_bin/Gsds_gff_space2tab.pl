#!/usr/bin/perl
#This script is used to remove space lines and comment lines, and convert space delimiter to tab
die "Error!\nUsage:\nperl Name.pl  original_file space2tab_file\n" if(@ARGV != 2);

($infile,$outfile)=@ARGV;
open(IN,"<$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";

while (<IN>) {
	if(/^\s*$/ or /^#/){
		next;
	}
	chomp;
	@matches=split(/\s+/,$_,9);
	print OUT join("\t",@matches)."\n"; 
}

