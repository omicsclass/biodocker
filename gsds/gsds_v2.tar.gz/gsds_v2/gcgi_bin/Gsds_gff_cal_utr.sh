# This script is used to calulate the coordinate of UTR
exon_type=`cut -f4 tmp_cal.bed|sort|uniq`
if [[ "$exon_type" =~ "CDS" ]] ;
then
	if [[ "$exon_type" =~ "exon" ]] ;
	then
		../../gcgi_bin/bedtools subtract -a tmp_exon -b tmp_CDS |awk '{if(/\texon\t/)sub(/\texon\t/,"\tUTR\t");print $0;}'>tmp_UTR
		cat tmp_UTR tmp_CDS > CDS_UTR.gff
	elif [[ "$exon_type" =~ "UTR" ]] ;
	then
		cat tmp_UTR tmp_CDS > CDS_UTR.gff
	else
		mv tmp_CDS CDS_UTR.gff
	fi
elif  [[ "$exon_type" =~ "exon" ]];
then
	if [[ "$exon_type" =~ "UTR" ]];
	then
		../../gcgi_bin/bedtools subtract -a tmp_exon -b tmp_UTR |awk '{if(/\texon\t/)sub(/\texon\t/,"\tCDS\t");print $0;}'>tmp_CDS
		cat tmp_UTR tmp_CDS > CDS_UTR.gff
	else
		awk '{if(/\texon\t/)sub(/\texon\t/,"\tCDS\t");print $0>"CDS_UTR.gff";}' tmp_exon
	fi
else
	exit "no CDS or exon in the gff file!\n";
fi
