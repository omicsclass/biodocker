#!/bin/bash
# This script is used to deal with GTF/GFF3 file and convert them to BED format for drawing

mkdir task/$1
cd task/$1
bash ../../gcgi_bin/Gsds_upload_other_file.sh
cp ../upload_file/$1.gff ./ 
#remove the space lines, comment lines, and special characters in windows OS. 
cat $1.gff|sed '/^[[:space:]]*$/d'|grep -v -P "^#"|sed "s///g"|sed 's/$/;/'>tmp_original.gff

#convert space delimiter to tab
perl ../../gcgi_bin/Gsds_gff_space2tab.pl tmp_original.gff tmp2
mv tmp2 tmp_original.gff

#retrieve required information from GTF/GFF3 file and convert them to BED format
cut -f3 tmp_original.gff >tmp_ele_type
cut -f4,5 tmp_original.gff >tmp_st_ed
cut -f7,8 tmp_original.gff >tmp_strd_phs
cut -f9 tmp_original.gff >tmp_line9
perl ../../gcgi_bin/Gsds_type2num.pl tmp_ele_type tmp_type
if test $3 == "gtf"
	then
	cat tmp_line9|awk '{if(/gene_id \"(.+)\"/){sub(/.*gene_id \"/,"");sub(/\".*/,"");print $0} else {print "0"}}' >tmp_gid
	cat tmp_line9|awk '{if(/transcript_id \"(.+)\"/){sub(/.*transcript_id \"/,"");sub(/\".*/,"");print $0} else {print "0"}}' >tmp_tid
	cat tmp_line9|awk '{if(/gene_name \"(.+)\"/){sub(/.*gene_name \"/,"");sub(/\".*/,"");print $0} else {print "0"}}' >tmp_gname
	cat tmp_line9|awk '{if(/transcript_name \"(.+)\"/){sub(/.*transcript_name \"/,"");sub(/\".*/,"");print $0} else {print "0"}}' >tmp_tname
	paste tmp_tid tmp_st_ed tmp_type tmp_strd_phs tmp_gid tmp_tname tmp_gname > tmp_parsed.bed
else if test $3 == "gff3"  
	then
	paste tmp_type tmp_line9 >tmp2
	perl ../../gcgi_bin/Gsds_gff3_find_gtid.pl tmp2 tmp_tid tmp_other_id
	paste tmp_tid tmp_st_ed tmp_type tmp_strd_phs tmp_other_id> tmp_parsed.bed

fi
fi
cat tmp_parsed.bed|sort -s -k7,7 -k1,1 -k2,2n> tmp_sorted.bed
perl ../../gcgi_bin/Gsds_gff_cal_every_transcript.pl tmp_sorted.bed tmp_cal.bed

#convert to 0-based BED file, map other features onto them, and then sort it by order file for drawing
bash ../../gcgi_bin/Gsds_extract_domain.sh
bash ../../gcgi_bin/Gsds_gff_cal_utr.sh
cat CDS_UTR.gff|sort -s -k2,2 -k1,1 -k4,4n> tmp_sorted.gff
awk '{print $1"\t"$4"\t"$5"\t"$3"\t"$7"\t"$8"\t"$2"\t"$6"\t"$9}' tmp_sorted.gff >for_drawing.bed
bash ../../gcgi_bin/Gsds_map_domain.sh
bash ../../gcgi_bin/Gsds_sort_gene_by_order_file.sh 
