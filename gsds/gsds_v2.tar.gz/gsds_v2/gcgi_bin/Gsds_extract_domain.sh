#!/usr/bin/bash
#This script is used to retrieve the information of other features and convert them into GFF format

perl ../../gcgi_bin/Gsds_bed2gff.pl tmp_cal.bed tmp_cal.gff
awk '{print >>"domains/tmp_"$3}' tmp_cal.gff
mv `ls domains/*|grep -i -P "tmp_(UTR|CDS|exon|gene|mRNA|transcript)$"` ./
#rm `ls domains/*|grep -i -P "tmp_intron$"` ./
