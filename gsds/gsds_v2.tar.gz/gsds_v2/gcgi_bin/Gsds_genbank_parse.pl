#!/usr/bin/perl
#This script is used to retrieve coordinate information from GenBank file

use Bio::SeqIO;
use Bio::LocationI;
use Data::Dumper;
die "Error!\nUsage:\nperl Name.pl genbank_file parsed.bed gene_start_end\n" if(@ARGV != 3);

($gb_file,$outfile,$gene_st_ed_file)=@ARGV;
open(IN,"<$gb_file")||die "Can't open file $gb_file";
open(OUT,">$outfile")||die "Can't open file $outfile";
open(OUT_Gene,">$gene_st_ed_file")||die "Can't open file $gene_st_ed_file";

my @gbid; 
#Store the entry IDs to @gbid
while(<IN>){
	if(/^Count = (\d+); QueryKey = (\S+)/){
		if ($1){
			push @gbid,$2;
		}
	}
}


my $seqio_object = Bio::SeqIO->new(-file => $gb_file);

my $j=0;
#Retrieve coodinate information for fearures from GenBank file
while (my $seqobj = $seqio_object->next_seq){
	$query_id=$gbid[$j];
	$seqid=$seqobj->id;
	print $seqid."\n";
	foreach my $feat ($seqobj->top_SeqFeatures){
		if($feat->primary_tag eq 'gene') {
			$gid=getGeneID($feat,$seqid);
			$gstart=$feat->location->start;
			$gend=$feat->location->end;
                	printFeature($gid,$gstart,$gend,'gene',$query_id);
			#Print gene start and end into gene_start_end file for spliting gene sequences
			print OUT_Gene "$query_id\t$gid\t$gstart\t$gend\n";
		} elsif ($feat->primary_tag eq 'mRNA' ){
			$gid=getGeneID($feat,$seqid);
			if (! $hasTranscript{$gid}){
				$hasTranscript{$gid}=1;
		   		foreach my $location ( $feat->location->each_Location ) {
	                		printFeature($gid,$location->start,$location->end,'exon',$query_id);
				}
        		}
		} elsif ($feat->primary_tag eq 'CDS' ){
			$gid=getGeneID($feat,$seqid);
			if (!$hasCDS{$gid}) {
				$hasCDS{$gid}=1;
	   			foreach my $location ( $feat->location->each_Location ) {
                			printFeature($gid,$location->start,$location->end,'CDS',$query_id);
        			}
			}
		} elsif ($feat->primary_tag eq "5\'UTR"){
			$gid=getGeneID($feat,$seqid);
			if (!$has5utr{$gid}){
				$has5utr{$gid}=1;
				foreach my $location ( $feat->location->each_Location ) {
       	         		printFeature($gid,$location->start,$location->end,'UTR',$query_id);
        			}
			}
		} elsif ($feat->primary_tag eq "3\'UTR"){
			$gid=getGeneID($feat,$seqid);
			if (!$has3utr{$gid}){
				$has3utr{$gid}=1;
				foreach my $location ( $feat->location->each_Location ) {
                			printFeature($gid,$location->start,$location->end,'UTR',$query_id);
        			}
			}
		} elsif ($feat->primary_tag eq 'exon' ){
			$gid=getGeneID($feat,$seqid);
			if (!$hasTranscript{$gid}){
				my $loc=$feat->location;
                		printFeature($gid,$loc->start,$loc->end,'exon',$query_id);
			}
		}
	}
$j++;
}

sub printFeature {
	my ($gid,$start,$end,$type,$query_id)=@_;
	$strand='+';
	$phase='.';
	$gname=$gid;
	$gname=~s/.*\_//;
	$seqname=$query_id;
	$string=join("\t",($gid,$start,$end,$type,$strand,$phase,$query_id,$gname,$seqname));
	print OUT $string."\n";
}

sub getGeneID {
	my ($feature,$sqid)=@_;
	my $gname;
	if ($feature->has_tag('gene')){
print "ifif\n";
		my @gname1=$feature->get_tag_values('gene');
		$gname=$gname1[0];
	}else{
		$gname=$sqid;
	}
print "aa $gname aa\n";
	#specify which sequnece the gene come from, because genes with the same names may come from different sequence
	$gid=$sqid."_".$gname;
	return $gid;
}
