#!/usr/bin/perl
#This script is used to get the IDs of genes and transcripts for display

die "Error!\nUsage:\nperl Name.pl for_drawing_file gid_file tid_file\n" if(@ARGV != 3);
($fd_file, $gid_file, $tid_file)=@ARGV;

open(IN,"<$fd_file")||die "Can't open file $fd_file";
open(OUT_GID,">$gid_file")||die "Can't open file $gid_file";
open(OUT_TID,">$tid_file")||die "Can't open file $tid_file";
while(<IN>){
	chomp;
	@match=split("\t", $_);
	if($match[8] and $match[8] ne '.'){
		print OUT_GID $match[8]."\n";
	}else{
		print OUT_GID $match[6]."\n";
	}

	if($match[7] and $match[7] ne '.'){
		print OUT_TID $match[7]."\n";
	}else{
		print OUT_TID $match[0]."\n";
	}
}	
close (OUT_GID);
close (OUT_TID);
close (IN);
	

