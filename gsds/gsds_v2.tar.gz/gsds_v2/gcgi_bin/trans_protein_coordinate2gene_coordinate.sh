#!/bin/bash
#This program is used to transform coordinates on proteins to corresponding genes.
type=$1

if [ -s tmp_CDS ];
then
	if [ $type == 'fasta' ]; then
		cat tmp_CDS|awk '{print $1"\t"$2-1"\t"$3}' >tmp_CDS_0based
	elif [ $type == 'site' ]; then
		cat tmp_CDS |awk '{print $1"\t"$4-1"\t"$5}' >tmp_CDS_0based
	else
		cat tmp_CDS |awk '{print $2"\t"$4-1"\t"$5}' >tmp_CDS_0based	
	fi

	sort -k1,1 -k2,2n tmp_CDS_0based >tmp_CDS_0based_tmp; mv tmp_CDS_0based_tmp tmp_CDS_0based
	cat tmp_dm1 | sed -e 's/$//' | awk '{print $1"\t"$2*3"\t"$3*3"\t"$4}' >tmp_dm1_CDSCoord
	sort -k1,1 -k2,2n tmp_dm1_CDSCoord >tmp_dm1_tmp; mv tmp_dm1_tmp tmp_dm1_CDSCoord
	cat tmp_CDS_0based | perl ../../gcgi_bin/trans_coordinate2CDS.pl >tmp_CDS_in_CDS_coordinate
	../../gcgi_bin/bedtools intersect -a tmp_dm1_CDSCoord -b tmp_CDS_in_CDS_coordinate  >tmp_dm1_To_gene
	../../gcgi_bin/bedtools intersect -a tmp_dm1_To_gene -b tmp_CDS_in_CDS_coordinate -wao >tmp_dm1_To_gene2
	awk '{print $1"\t"$2+$8"\t"$3+$8"\t"$4}' tmp_dm1_To_gene2 >tmp_dm1
fi
	 
