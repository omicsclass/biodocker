#!/usr/bin/perl
#This script is used to find out mRNA id and gene id for every feature

die "Usage: Name.pl type_line2+9_file tid_file other_id_file\n" if (@ARGV!=3);
($infile,$tid_file,$other_id_file)=@ARGV;
#infile: <feature type> <9th line in GFF3 file>
#tid_file: <mRNA id for each feature>
#other_id_file: <gene id> <mRNA name> <gene name>

open(IN,"$infile")||die "Can't open file $infile";
open(OUT1,">$tid_file")||die "Can't open file $tid_file";
open(OUT2,">$other_id_file")||die "Can't open file $other_id_file";

#Record IDs and names of genes and mRNAs
#Set gene and mRNA name as 0, when the id is 0
$genes{0}{name}="0";
$mRNAs{0}{name}="0";

#Record the parent gene for each mRNA
while(<IN>){
	@match=split("\t",$_);
	if($match[1]=~/ID=(.*?);/i){
		$id=$1;
		if($match[0] eq "gene"){
			$genes{$id}{tag}=1;
			if($match[1]=~/Name=(.*?);/){
			$genes{$id}{name}=$1;
			}else{
			$genes{$id}{name}="0";
			}
		}
		elsif($match[0] eq "mRNA"){
			$mRNAs{$id}{tag}=1;
			if($match[1]=~/Parent=(.*?);/i){
			$mRNAs{$id}{parent}=$1;
			}else{
			$mRNAs{$id}{parent}="0";
			}
			if($match[1]=~/Name=(.*?);/){
			$mRNAs{$id}{name}=$1;
			}else{
			$mRNAs{$id}{name}="0";
			}
		}
	}
}

#Back to the beginning of the file
seek(IN,0,0);

#Print out gene and mRNA ID for each feature
while(<IN>){
	@match=split("\t",$_);
	if($match[0] eq "gene"and $match[1]=~/ID=(.*?);/){
		printIDs("0",$1,"0",$genes{$1}{name});
	}elsif($mathc[0] eq "mRNA" and $match[1]=~/ID=(.*?);/){
		my $g_id=$mRNAs{$1}{parent};
		printIDs($1,$g_id,$mRNAs{$1}{name},$genes{$g_id}{name});		
	}elsif($match[1]=~/Parent=(.*?);/i){
		my($t_id,$g_id)=findParent($1);
		printIDs($t_id,$g_id,$mRNAs{$t_id}{name},$genes{$g_id}{name});
	}else{
		printIDs('0','0','0','0');
	}
	
}

sub printIDs {
	my ($t_id,$g_id,$t_name,$g_name)=@_;
	print OUT1 "$t_id\n";
	print OUT2 "$g_id\t$t_name\t$g_name\n";
}
sub findParent {
	my ($p_id)=@_;
	my ($t_id, $g_id);
	if ($genes{$p_id}{tag}){
		$t_id="0";
		$g_id=$p_id;
		return ($t_id,$g_id);
	}elsif ($mRNAs{$p_id}{tag}){
		$t_id=$p_id;
		$g_id=$mRNAs{$t_id}{parent};
		return ($t_id,$g_id);
	}else{
		return ("0","0");
	}
}
