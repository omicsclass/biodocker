#!/usr/bin/perl

######################################################################################
## Guoay 2003-9-29
## compute the length of every sequence in a fasta file 
## and write the seq id and the length into another file
##
## Input: fasta seq file
## Output: id and length file
######################################################################################

defined(@ARGV) || die "Usage:\nperl Name.pl fasta_seq_file id_and_length_file\n";
die "Error!\nUsage:\nperl Name.pl fasta_seq_file id_and_length_file\n" if(@ARGV != 2);
($infile,$outfile)=@ARGV;
open(IN,"<$infile");
open(OUT,">$outfile");
use Data::Dumper;

my $id,$seq;
while (<IN>) {
	s#\r##g;
	if (/^>/) {
		# before reading a new seq,deal with the previous seq's result
		if ($id ne "") {
			print OUT $id."\t".length($seq)."\n";
			$id="";
			$seq="";
		}
		# deal with the next sequence
		#/^>(\w+)/;
		/^>(\S+)\s/;
		$id=$1;   
	}
	else{
		chomp($_);
		$seq=$seq.$_;
	}
}
# because in the above while circle,the last seq's id and length don't be write into the OUT file
# Here we should add them into it.
print OUT $id."\t".length($seq)."\n";
print "+Done\n";
