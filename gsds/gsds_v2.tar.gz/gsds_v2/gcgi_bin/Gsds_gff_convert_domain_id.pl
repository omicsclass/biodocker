#!/usr/bin/perl
#This script is used to convert file to BED file for drawing

die "Usage: Name.pl domain_file for_drawing_file\n" if (@ARGV!=2);

($dmfile,$fdfile)=@ARGV;
open(DM,"$dmfile")||die "Can't open file $dmfile";
open(FD,"$fdfile")||die "Can't open file $fdfile";
open(TMP,">tmp_$dmfile")||die "Can't open file tmp_$fdfile";
@gid_arr=`cut -f7 $fdfile|sort|uniq`;
@tid_arr=`cut -f1 $fdfile|sort|uniq`;
foreach (@gid_arr,@tid_arr){
	chomp;
}
while(<FD>){
print $_;
	@m=split("\t",$_);
	push(@{$g2t{$m[6]}},$m[0]);
	$t2g{$m[0]}=$m[6];
}

while(<DM>){
	chomp;
	@m=split("\t",$_);
	$fid=$m[0];
	if ($g2t{$fid}){
		$m[6]=$fid;
		foreach $tid (@{$g2t{$fid}}){
			$m[0]=$tid;
			print TMP join("\t",@m)."\n";
		}
	}elsif(grep("/^$m[0]\$/",keys %t2g)){
			$m[6]=$t2g{$fid};
			print TMP join("\t",@m)."\n";
	}
}

close(DM);
close(FD);
close(TMP);

`mv tmp_$dmfile $dmfile`

