#!/usr/bin/perl
#This script is used to draw tree

use Bio::Phylo::IO 'parse';
use Bio::Phylo::Treedrawer;
($ran,$format,$tree_width,$t_num,$int_height)  = @ARGV;

$path="task/$ran";
$tree="$path/$ran.tree";
$tree_pic="$path/tree.".$format;
open TR,$tree ||die "Can't open tree file: $!\n";
open TR_PIC,">$tree_pic" ||die "Can't open tree picture file: $!\n";

my $tree_string="";
while(<TR>){
	chomp;
	$tree_string.=$_;
}
my $tree = parse( -format => 'newick', -string => $tree_string )->first;

my $treedrawer = Bio::Phylo::Treedrawer->new(
-width  => $tree_width,
-height => $int_height*($t_num+2),
-padding => $int_height,
-text_width => 1,
-shape  => 'RECT',
#-mode   => 'PHYLO', # phylogram
-mode   => 'CLADO',
-format => $format,
);

$treedrawer->set_tree($tree);
print TR_PIC $treedrawer->draw;
print "IF_APPEAR_IN_TREE_O_THEN_DRAW_TREE_SUCCEEDED";

