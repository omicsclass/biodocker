#!/usr/bin/perl

## Guoay 07-1-28

## add the 3UTR site to fragment site file

#seq1    342     640
#seq1    732     828
#seq2    91      416
#seq2    504     723

die "Error!\nUsage:\nperl Name.pl fragment_site gene_length \nThe result of fragment site will print on screen\n" if(@ARGV != 2);

($infile,$infile2)=@ARGV;

open(IN,"$infile")||die "Can't open file $infile $!";
open(IN2,"$infile2")||die "Can't open file $infile2 $!";

my %hash_len;
while(<IN2>){
	/(\S+)\s+(\d+)/;
	$hash_len{$1}=$2;
}
while (<IN>) {
	/(\S+)\s+(\d+)\s+(\d+)/;
	$id=$1;
	# a new id, check the last id has 3UTR or not
	if ($id ne $oldid){
		if ($oldend!=$hash_len{$oldid}){
			$utr3_start=$oldend+1;
			print $oldid."\t".$utr3_start."\t".$hash_len{$oldid}."\n";
		}
	}
	$oldid=$id;
	$oldend=$3;
	print $_;
}
# check the last one
if ($oldend!=$hash_len{$oldid}){
	$utr3_start=$oldend+1;
        print $oldid."\t".$utr3_start."\t".$hash_len{$oldid}."\n";
}
