#!/usr/bin/perl

## guoay 05-11-20
## get the fasta seq by id,start_number and end_number in another file
##
## such as the pfscan out At2g03710     257		333
##						  At2g03720     27		88
## and merge the two sequence part of the same id to one
## Input: seq.fasta,id+site 
## Output:subseq

die "Error!\nUsage:\nperl Name.pl seq.fasta id+site \n" if(@ARGV != 2);
($infile,$infile2)=@ARGV;
#open(IN1,"<$infile")||die "Can't open file $infile";
open(IN2,"<$infile2")||die "Can't open file $infile2";

my %hash_start,%hash_end;
# read the id+site into a hash table
while (<IN2>) {
	/(\S+)\s+(\d+)\s+(\d+)/;
	$id=$1; $start=$2; $end=$3;
	$out=$id."_".$start."_".$end;
	`seqret $infile:$id sbegin=$start send=$end $out`;
	`sed '1 d' $out >tmp; mv tmp $out`;
	`echo ">"$id"	sequence from "$start" to "$end |cat - $out >tmp; mv tmp $out`;
}
