#!/usr/bin/perl -w
#This script is used to transform coordinates on genes to coordinates on CDSs.

use warnings;

my ($pre_id, $cds_length, $base_No);
while(<>){
	chomp;
	my ($id, $start, $end)=split(/\s+/);
	if((! defined($pre_id)) || ($id ne $pre_id) ){
		$pre_id=$id;
		$base_No=$start;
		$cds_length=$end -$start;
		print "$id\t0\t$cds_length\t$base_No\n";
		next;
	}
	if($id eq $pre_id){
		$base_No=$start - $cds_length;
		print "$id\t$cds_length\t";
		$cds_length=$cds_length + $end -$start;
		print "$cds_length\t$base_No\n";
	}
}
