#!/usr/bin/perl
#This script is used to convert chromosome coordinates into gene coordinates
die "Usage: Name.pl id_sorted_file calculated_file\n" if (@ARGV!=2);
($infile,$outfile)=@ARGV;
open(IN,"$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";

#Variable to record features in a transcript
my @ele;
#Variable to record current gene ID and transcript ID
my ($gid,$tid)=(0,0);

while(<IN>){
        $line=$_;
        @match=split("\t",$_);
	#If current transcript id doesn't change, continue to push feature into @ele
	if($match[0] eq $tid){
		#Push feature into @ele 
		push @ele, [@match];
		#Update the start and end of the transcript
		updateSE($match[1],$match[2]);
		#If current transcript ID changes, output previous transcript and record new one
	}else{
		#Output features in previous transcript
		if($tid){
			foreach my $e (@ele){
				#calculate the coordinate on genes
				if($strand=~/\+/){
					$$e[1]-=($t_start-1);
					$$e[2]-=($t_start-1);
				}else{
					my $ori_e2=$$e[2];
					$$e[2]=$t_end-$$e[1]+1;
					$$e[1]=$t_end-$ori_e2+1;
				}
				if ($strand=~/\+/){
					print OUT join("\t",@{$e});
				}
			}
			if ($strand=~/\-/){
				foreach my $e (reverse @ele){
					print OUT join("\t",@{$e});
				}
			}
		}
		
		#Record ID, start, end and strand of the new transcript
		$tid=$match[0];
		$t_start=$match[1];
		$t_end=$match[2];
		$strand=$match[4];
		#Empty @ele
		@ele=();
		push @ele, [@match];
        }
}
#Output the last transcript
if($tid){
			foreach my $e (@ele){
				#Calculate the coordinate on genes
				if($strand=~/\+/){
					$$e[1]-=($t_start-1);
					$$e[2]-=($t_start-1);
				}else{
					my $ori_e2=$$e[2];
					$$e[2]=$t_end-$$e[1]+1;
					$$e[1]=$t_end-$ori_e2+1;
				}
				if ($strand=~/\+/){
					print OUT join("\t",@{$e});
				}
			}
			if ($strand=~/\-/){
				foreach my $e (reverse @ele){
					print OUT join("\t",@{$e});
				}
			}

}

sub updateSE {
        my($ns,$ne)=@_;
        $t_start=$ns if ($t_start>$ns);
        $t_end=$ne if ($$t_end<$ne);
}
