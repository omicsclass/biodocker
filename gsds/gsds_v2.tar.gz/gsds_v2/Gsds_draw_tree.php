<?php 
//draw the tree

if($cgi_info['order_by_gene_id']){
	$tree_t_num=$g_num;
}else{
	$tree_t_num=$t_num;
}
$tree_e=escapeshellcmd("perl gcgi_bin/Gsds_draw_tree.pl $ran svg $tree_width $tree_t_num $int_height");
exec($tree_e,$tree_o,$tree_s);
$tree_s=$tree_o[0];


if($tree_s and file_exists("$path/tree.svg")){
	$doc = new DOMDocument();
	$doc->load( "$path/tree.svg" );
	
	$tree_polylines = $doc->getElementsByTagName( "polyline" );
	foreach( $tree_polylines as $pl ){
		$point_string=preg_split("/\s/",$pl->getAttribute("points"));
		$points=array();
		foreach($point_string as $ps){
			$p=preg_split("/,/",$ps);
			$points[]=$p;
		}
		if($cgi_info['order_by_gene_id']){
			#tree_polyline_points
			$tpp[]=$points;
		}else{
			tree_line($points[0][0],$points[0][1],$points[1][0],$points[1][1],$tree_color,$tree_strw);
			tree_line($points[1][0],$points[1][1],$points[2][0],$points[2][1],$tree_color,$tree_strw);
		}
	}
	if($cgi_info['order_by_gene_id']){
		usort($tpp, "sort_tree_branch");
	}
	
}else{
	$cgi_warning[]="Error in drawing tree! Please check the tree file format!";
}
function sort_tree_branch($a, $b){
	    $a = $a[1][1];
	    $b = $b[1][1];
	
	    if ($a == $b) {
	        return 0;
	    }
	    return ($a < $b) ? -1 : 1;
	}
?>
