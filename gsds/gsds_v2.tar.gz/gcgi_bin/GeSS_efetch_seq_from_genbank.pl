#!/usr/local/bin/perl -w
#
# Author:  Guo An-Yuan
# revise from NCBI efetch
#
# File Description: eSearch/eFetch calling example
#  
# ---------------------------------------------------------------------------
# Define library for the 'get' function used in the next section.
# $utils contains route for the utilities.

use LWP::Simple;

die "Error Found!\n" if(@ARGV != 2);;
($infile,$outfile) = @ARGV;
open(IN,"<$infile") || die "Can't open $infile";
open(OUT,">$outfile") || die "Can't open $outfile";

my $utils = "http://www.ncbi.nlm.nih.gov/entrez/eutils";
my $db = "nuccore";
my $report = "gb";

# check the id file in php, it should be one gi or ACC on one line
my @seq_id=<IN>;

# ---------------------------------------------------------------------------
# $esearch cont��ins the PATH & parameters for the ESearch call
# $esearch_result containts the result of the ESearch call
# the results are displayed ��nd parsed into variables 
# $Count, $QueryKey, and $WebEnv for later use and then displayed.

foreach my $id (@seq_id){
	my $query = $id;
	my $esearch = "$utils/esearch.fcgi?" . "db=$db&retmax=1&usehistory=y&term=";
	
	my $esearch_result = get($esearch . $query);
	
	$esearch_result =~ 
	  m|<Count>(\d+)</Count>.*<QueryKey>(\d+)</QueryKey>.*<WebEnv>(\S+)</WebEnv>|s;
	
	my $Count    = $1;
	my $QueryKey = $2;
	my $WebEnv   = $3;
	
	print OUT "Count = $Count; QueryKey = $query\n";
	
	my $efetch = "$utils/efetch.fcgi?" .
		"rettype=$report&retmode=text&".
	        "db=$db&query_key=$QueryKey&WebEnv=$WebEnv";
		
	my $efetch_result = get($efetch);
	  
	print OUT "$efetch_result\n";
}
