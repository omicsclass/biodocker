#!/usr/bin/perl
#This script is used to convent exon postion file and gene length file to the BED file

die "Usage: Name.pl exon_pos_file utr_pos_file gene_length_file\n" if (@ARGV!=3);

($infile,$outfile,$glfile)=@ARGV;
open(IN,"$infile")||die "Can't open file $infile";
open(GL,"$glfile")||die "Can't open file $glfile";
open(OUT,">$outfile")||die "Can't open file $outfile";
my $gid=0;
my $t_end=0;
my $g_length=0;
while(<IN>){
        $line=$_;
        @match=split("\t",$_);
	if($match[0] eq $gid){
		$t_end=$match[2];
		chomp($t_end);
	}else{
		if($gid and $t_end<$g_length){
			print OUT "$gid\t".($t_end+1)."\t$g_length\tUTR\t.\t.\n";
		}
		$gid=$match[0];
		seek(GL,0,0);
		while (<GL>) {
			if(/^(\S+)(\s+)(\S+)/){
				if ($gid eq $1) {
					$g_length=$3;
				}
			}
		}
		$t_end=$match[2];
		chomp($t_end);
		if($match[1]>1){
			print OUT "$gid\t1\t".($match[1]-1)."\tUTR\t.\t.\n";
		}
	}
}
if($gid and $t_end<$g_length){
	print OUT "$gid\t".($t_end+1)."\t$g_length\tUTR\t.\t.\n";
}
