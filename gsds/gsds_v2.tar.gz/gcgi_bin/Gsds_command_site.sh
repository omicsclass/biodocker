#!/bin/bash
#This script is used to deal with BED file for drawing

mkdir task/$1
cd task/$1
ran=$1
bash ../../gcgi_bin/Gsds_upload_other_file.sh $ran
cp ../upload_file/$1.site .

#Reomve space line, and special characters in Windows OS, and convert it to consistent BED file
sed '/^[[:space:]]*$/d' $1.site |sed 's//\n/g'> tmp_original.bed
perl ../../gcgi_bin/Gsds_site_parse.pl tmp_original.bed tmp_cal.bed
bash ../../gcgi_bin/Gsds_extract_domain.sh 
bash ../../gcgi_bin/Gsds_gff_cal_utr.sh
less CDS_UTR.gff|sort -s -k2,2 -k1,1 -k4,4n> tmp_sorted.gff
awk '{print $1"\t"$4"\t"$5"\t"$3"\t"$7"\t"$8"\t"$2"\t"$6"\t"$9}' tmp_sorted.gff >for_drawing.bed

#Map other features onto them, and sort them by gene order file for drawing
bash ../../gcgi_bin/Gsds_map_domain.sh $ran
bash ../../gcgi_bin/Gsds_sort_gene_by_order_file.sh 
