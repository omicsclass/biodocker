#!/usr/bin/perl
#This script is used to sort file by the id order file.
use JSON;

## Input: file_for_sorting, ID_order_file
## Output: sorted_file
die "Error!\nUsage:\nperl Name.pl  file_for_sorting ID_order_file sorted_file\n" if(@ARGV != 3);

($infile,$idfile,$outfile)=@ARGV;
if(!open(IN,"<$infile")){
	$cgi_info['for_drawing_exists']=0;
	print encode_json \%cgi_info;
	die "Can't open file $infile";
}
open(ID,"<$idfile")||die "Can't open file $idfile";
open(OUT,">$outfile")||die "Can't open file $outfile";

@gid_arr=`cut -f7 $infile|sort|uniq`;
@tid_arr=`cut -f1 $infile|sort|uniq`;
$cgi_info{'g_num'}=scalar(@gid_arr);
$cgi_info{'t_num'}=scalar(@tid_arr);
foreach (@gid_arr,@tid_arr){
	chomp;
}
%gid= map {$_ => 1} @gid_arr;
%tid= map {$_ => 1} @tid_arr;
while(<ID>){
	if(/^(\S+)/){
		$id=$1;
		$id_num++;
		if($gid{$id}){
			$gid_num++;
		}
		if($tid{$id}){
			$tid_num++;
		}
	}
}
if($gid_num and $tid_num){
	$cgi_info{'error'}.="Gene id and transcript id should not be mixed in order file or tree file!";
	`cp $infile $outfile`;
	print encode_json \%cgi_info;
	die;
}elsif($gid_num){
	$cgi_info{'lack_id_num'}=$id_num-$gid_num;
	$cgi_info{'discard_id_num'}=$gid_num-scalar(@gid_arr);
	$cgi_info{'order_by_gene_id'}=1;
}elsif($tid_num){
	$cgi_info{'lack_id_num'}=$id_num-$tid_num;
	$cti_info{'discard_id_num'}=$tid_num-scalar(@tid_arr);
	$cgi_info{'order_by_gene_id'}=0;
}else{
	$cgi_info{'error'}.="ID(s) in order file or tree file can't be found in gene file.";
	`cp $infile $outfile`;
	print encode_json \%cgi_info;
	die;
}

	if($cgi_info{'lack_id_num'}){
		$cgi_info{'warning'}=abs($cgi_info{'lack_id_num'})." ID(s) in order file or tree file are not found in gene file!";
	}elsif($cgi_info{'discard_id_num'}){
		$cgi_info{'warning'}=abs($cgi_info{'discard_id_num'})." ID(s) in gene file are not given in order file or tree file and the genes are not shown!";
	}


my %ids;
seek(ID,0,0);
while (<ID>) {
	if(/^(\S+)/){
	$id=$1;
	#Before sort for each ID, reset the file for sorting to the begin
	seek(IN,0,0);
	while (<IN>) {
		$line=$_;
		chomp;
		@m=split(/\t/);
		if($cgi_info{'order_by_gene_id'}){
			$line_id=$m[6];
		}else{
			$line_id=$m[0];
		}
		if ($id eq $line_id) {
			print OUT $line;
			$ids{$id}=1;
		}
	}
	if(!$ids{$id}){
		if($cgi_info{'order_by_gene_id'}){
			print OUT '.'.("\t." x 5)."\t$id".("\t." x 2)."\n";
		}else{
			print OUT $id.(".\t" x 8)."\n";
		}
	}
	}
}
close(IN);
close(OUT);
close(ID);
`mv $outfile $infile`;
print encode_json \%cgi_info;
