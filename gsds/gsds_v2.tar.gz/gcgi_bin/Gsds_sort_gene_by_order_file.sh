#This script is used to generate ID order file

if [ -e $1.tree ]
then
	perl ../../gcgi_bin/Gsds_tree2order.pl $1.tree $1.order
fi

if test -e $1.order
   then
	sed 's/,/\n/g' $1.order |sed 's/;/\n/g'|sed 's/\t\+/\n/g' |sed 's/ \+/\n/g' |sed '/^[[:space:]]*$/d'>tmp; mv tmp $1.order
fi

