#!/usr/bin/perl
#This script is used to convert feature types to consistent annotation

die "Error!\nUsage:\nperl Name.pl  original_file type2num_file\n" if(@ARGV != 2);
($infile,$outfile)=@ARGV;
open(IN,"<$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";

$stdTypes{"gene"}="gene";
$stdTypes{"mRNA"}="mRNA";
$stdTypes{"transcript"}="mRNA";
$stdTypes{"five_prime_UTR"}="UTR";
$stdTypes{"three_prime_UTR"}="UTR";
$stdTypes{"UTR"}="UTR";
$stdTypes{"exon"}="exon";
$stdTypes{"CDS"}="CDS";
while (<IN>) {
	if(/^(\S+)/){
	if ($stdTypes{$1}) {
		print OUT "$stdTypes{$1}\n";
	}else{
		print OUT "$1\n";
	}
	}
}

