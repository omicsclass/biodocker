#!/usr/bin/perl
#This script is used to convert coordinate in BED file to 1-based
#and correct some problems in original BED file.
die "Usage: Name.pl site_file parsed_file\n" if (@ARGV!=2);
($infile,$outfile)=@ARGV;
open(IN,"$infile")||die "Can't open file $infile";
open(OUT,">$outfile")||die "Can't open file $outfile";
while(<IN>){
	if(/^\s*$/){
		next;
	}
	chomp;
       	$line=$_;
	@m=split(/\s+/,$line);
	$m[1]+=1;

	for($n=0;$n<9;$n++){
		if(!defined($m[$n])){
			$m[$n]='.';
		}
	}
	$m[5]=$m[4];
	$m[4]='+';
	print OUT join("\t",@m)."\n";
}
close(IN);
close(OUT);
