#!/usr/bin/perl

## guoay 05-11-20
## get the fasta seq by id,start_number and end_number in another file
##
## such as the pfscan out At2g03710     257		333
##						  At2g03720     27		88
## and merge the two sequence part of the same id to one
## Input: seq.fasta,id+site 
## Output:subseq

die "Error!\nUsage:\nperl Name.pl seq.fasta id+site \n" if(@ARGV != 2);
($seqfile,$gene_start_end)=@ARGV;
open(IN,"<$gene_start_end")||die "Can't open file $gene_start_end";

# read the id+site into a hash table
while (<IN>) {
	/(\S+)\s+(\S+)\s+(\d+)\s+(\d+)/;
	$seqid=$1; $gid=$2; $start=$3; $end=$4;
	$out=$gid.".gene_seq";
	`seqret $seqfile:$seqid sbegin=$start send=$end $out`;
	`sed -i '1 d' $out`;
	`echo ">"$gid"	sequence from "$start" to "$end |cat - $out >tmp; mv tmp $out`;
}
