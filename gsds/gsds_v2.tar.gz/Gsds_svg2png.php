<?php
//convert SVG figure to other formats
$ran=$_GET['ran'];
$img_format=$_GET['img_format'];
$path="task/$ran";
$convert_command=escapeshellcmd("gcgi_bin/rsvg-convert -f $img_format -o $path/$ran.$img_format $path/$ran.svg");
exec($convert_command);
?>
<!DOCTYPE html>
<html>
<head>
<META HTTP-EQUIV="Refresh" CONTENT="0; url=<?php echo "$path/$ran.$img_format"?>">
</head>
<body>
</body>
</html>
